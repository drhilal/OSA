#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
for s in 01_quality_indices 02_differential 03_enrichment 04_pxd069503 05_verify; do
  echo "== $s"; python scripts/$s.py
done
