#!/usr/bin/env bash
# Tüm analizi çalıştırır. Girdiler veri/ klasöründe olmalıdır.
set -euo pipefail
cd "$(dirname "$0")"

MATRIS="veri/PXD073409_OSA_AI_ready_matrix.xlsx"
PANEL="veri/44321_2019_BFEMMM201910427_MOESM3_ESM.xlsx"

for f in "$MATRIS" "$PANEL"; do
  [ -f "$f" ] || { echo "HATA: $f bulunamadı. README.md > Girdi dosyaları."; exit 1; }
done

PY=${PYTHON:-python}
"$PY" -c "import pandas, numpy, scipy, statsmodels, sklearn, matplotlib, openpyxl" 2>/dev/null \
  || { echo "HATA: bağımlılıklar eksik. 'conda activate osa-analiz' yaptınız mı?"; exit 1; }

"$PY" src/pipeline.py --matrix "$MATRIS" --panels "$PANEL" \
      --outdir cikti --seeds "${SEEDS:-50}"

echo
echo "Bitti. cikti/SONUCLAR.md dosyasına bakın."
