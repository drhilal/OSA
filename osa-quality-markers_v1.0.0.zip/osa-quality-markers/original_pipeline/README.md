# Original analysis pipeline

Scripts used for the analyses of the submitted manuscript and the first-round revision. Comments in the code are partly in Turkish.

| Script | Run date | Output |
|---|---|---|
| `src/pipeline.py --enrichr` (with `panels.py`, `genesets.py`, `figures.py`) | 28 August 2026 | `cikti_enrichr/tables/T1-T9`, `cikti_enrichr/figures/` |
| `src/osa_revision_A.py` | 10 September 2026 | `cikti_revA/RevisionA_results.xlsx`, `cikti_revA/FigA5`, `FigA6` |
| `src/osa_revision_A2.py` | 10 September 2026 | `cikti_revA/RevisionA2_results.xlsx` (scenario enrichment with `genesets.enrichr_ora`) |

Supplementary Tables S5-S14 were taken from these outputs. Tables S1-S4, S11b, S11c and S15-S18 were regenerated for the second revision by the scripts in `../scripts`.

Input files are in `veri/`:
- `PXD073409_OSA_AI_ready_matrix.xlsx`: PXD073409 protein-group matrix (sheets `Raw_Linear`, `AI_Input_Log2`)
- `44321_2019_BFEMMM201910427_MOESM3_ESM.xlsx`: Table EV2 of Geyer et al. 2019 (EMBO Mol Med, CC BY 4.0)
- `Proteins.xls`: PXD069503 Proteome Discoverer protein table (tab-separated text)

Commands (from this folder):

```
conda env create -f environment.yml
conda activate osa-analiz
pip install gseapy
python src/pipeline.py --matrix veri/PXD073409_OSA_AI_ready_matrix.xlsx --panels veri/44321_2019_BFEMMM201910427_MOESM3_ESM.xlsx --outdir cikti_enrichr --seeds 50 --enrichr
python src/osa_revision_A.py
python src/osa_revision_A2.py
```

On Windows, run `set PYTHONUTF8=1` first.

The Enrichr libraries (GO_Biological_Process_2023, GO_Molecular_Function_2023, KEGG_2021_Human, Reactome_2022) are downloaded by gseapy (version 1.3.1 in the osa-analiz environment) at run time. They were retrieved on 28 August 2026 and again on 10 September 2026; the two downloads gave identical set sizes and P values for all 906 terms. The table `../data/ORA_terms_frozen.tsv` preserves these set sizes so that the reported enrichment results can be reproduced without a new download.

