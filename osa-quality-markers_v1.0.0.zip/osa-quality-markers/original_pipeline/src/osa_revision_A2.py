"""
Add-on to osa_revision_A.py (run from src/ after it):
  1. Table 3 recomputed with the project's own Enrichr ORA (genesets.enrichr_ora), so that
     the four scenarios use exactly the gene-set libraries behind manuscript Table 1.
  2. Second dataset (PXD069503): erythrocyte, platelet and coagulation indices OSA vs control,
     and quality-panel membership of the top differentially abundant proteins.
Output: cikti_revA/RevisionA2_results.xlsx
"""
import os, sys, re
import numpy as np, pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from panels import load_panels
from genesets import enrichr_ora

OUT = os.path.join(HERE, "..", "cikti_revA")
RES = os.path.join(OUT, "RevisionA_results.xlsx")
SECOND = os.path.join(HERE, "..", "veri", "Proteins.xls")
PANELS = os.path.join(HERE, "..", "veri", "44321_2019_BFEMMM201910427_MOESM3_ESM.xlsx")
pan = load_panels(PANELS)
x = pd.ExcelFile(RES)
w = pd.ExcelWriter(os.path.join(OUT, "RevisionA2_results.xlsx"), engine="openpyxl")

# ---------- 1. Table 3 with genesets.enrichr_ora ----------
ren = {"yolak": "term", "set_n": "set_size", "kesisim_n": "overlap", "genler": "genes"}
oraA = None; rows = []
for tag, name in [("A", "all, unadjusted"), ("B", "panel excluded, unadjusted"),
                  ("C", "panel excluded, index-adjusted"), ("D", "all, index-adjusted")]:
    de = x.parse(f"A3_DE_{tag}_")
    hits = de[(de.q < .25) & (de.log2FC.abs() >= .5)].protein.tolist()
    o = enrichr_ora(hits, de.protein.tolist()).rename(columns=ren)
    o.to_excel(w, sheet_name=f"T3_ORA_{tag}", index=False)
    if oraA is None: oraA = o
    nine = oraA[oraA.q < .25].term.tolist()
    ov = o.set_index("term").overlap.reindex(nine).fillna(0).astype(int)
    rows.append(dict(scenario=f"{tag}: {name}", n_tested=len(de), q05=(de.q < .05).sum(), q25=(de.q < .25).sum(),
                     q25_FC=len(hits), terms_q05=(o.q < .05).sum(), terms_q25=(o.q < .25).sum(),
                     top_term=o.term.iloc[0] if len(o) else "", top_q=o.q.iloc[0] if len(o) else np.nan,
                     **{f"overlap|{t}": int(v) for t, v in ov.items()}))
T3 = pd.DataFrame(rows); T3.to_excel(w, sheet_name="Table3", index=False)
print(T3.drop(columns=[c for c in T3.columns if c.startswith("overlap|")]).to_string())
print("Overlaps of the scenario-A terms in each scenario:")
print(T3[[c for c in T3.columns if c.startswith("overlap|")]].T.to_string())

# ---------- 2. Dataset 2 quality indices ----------
d2 = pd.read_csv(SECOND, sep="\t", encoding="utf-8", encoding_errors="replace")
ab = [c for c in d2.columns if c.startswith("Abundances (Normalized)")]
d2["gene"] = d2["Gene names"].astype(str).str.split(r"[;, ]").str[0].str.strip().replace({"HBA2": "HBA1"})
X2 = d2.groupby("gene")[ab].max().T.apply(pd.to_numeric, errors="coerce").replace(0, np.nan)
is_osa = pd.Series([bool(re.search(r"Sample OSA_", c)) for c in X2.index], index=X2.index)
rows = []
for name, spec in pan.items():
    genes = spec["plasma_up"] or spec["genes"]
    hit = sorted(c for c in X2.columns if c in genes)
    idx = X2[hit].sum(axis=1) / X2.sum(axis=1)
    a, b = idx[is_osa], idx[~is_osa]
    rows.append(dict(panel=name, n_quantified=len(hit), members=";".join(hit),
                     index_OSA=a.mean(), index_control=b.mean(), fold=a.mean() / b.mean(),
                     welch_p_log=stats.ttest_ind(np.log2(a), np.log2(b), equal_var=False).pvalue,
                     mannwhitney_p=stats.mannwhitneyu(a, b).pvalue, AUROC=roc_auc_score(is_osa.astype(int), idx)))
    X2[f"__{name}_index"] = idx
I2 = pd.DataFrame(rows); I2.to_excel(w, sheet_name="D2_quality_indices", index=False); print(I2.round(4).to_string())
# correlation between the three indices in dataset 2
ix = X2[[f"__{n}_index" for n in pan]].apply(np.log2)
ix.columns = list(pan); ix.corr(method="spearman").to_excel(w, sheet_name="D2_index_correlations"); print(ix.corr(method="spearman").round(2))
# panel membership of top DE proteins in dataset 2
de2 = x.parse("A6_DE2_unadjusted")
for name, spec in pan.items():
    de2[f"in_{name}_panel"] = de2.protein.isin(spec["genes"])
top = de2[de2.q < .05].copy()
summ = pd.DataFrame([dict(n_q05=len(top), n_up=(top.log2FC > 0).sum(), n_down=(top.log2FC < 0).sum(),
                          up_in_platelet=int(top[(top.log2FC > 0)].in_platelet_panel.sum()),
                          up_in_erythrocyte=int(top[(top.log2FC > 0)].in_erythrocyte_panel.sum()),
                          top20_in_platelet=int(top.head(20).in_platelet_panel.sum()),
                          top20_in_erythrocyte=int(top.head(20).in_erythrocyte_panel.sum()))])
summ.to_excel(w, sheet_name="D2_DE_panel_membership", index=False); print(summ.to_string())
de2.to_excel(w, sheet_name="D2_DE_annotated", index=False)
print(de2.head(25)[["protein", "log2FC", "q", "in_erythrocyte_panel", "in_platelet_panel"]].round(3).to_string())
# DE in dataset 2 adjusted for the platelet index (and for both indices)
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
lX2 = np.log2(X2[[c for c in X2.columns if not c.startswith("__")]])
lX2 = lX2.loc[:, lX2.notna().mean() >= .7]
def de_adj(covs):
    out = []
    y = is_osa.astype(float)
    for p in lX2.columns:
        if any(p in pan[k]["genes"] for k in covs): continue
        v = lX2[p]; ok = v.notna()
        if (ok & (y == 1)).sum() < 10 or (ok & (y == 0)).sum() < 10: continue
        Xd = pd.DataFrame({"group": y[ok]})
        for k in covs: Xd[k] = np.log2(X2[f"__{k}_index"])[ok]
        f = sm.OLS(v[ok], sm.add_constant(Xd)).fit()
        out.append(dict(protein=p, beta=f.params["group"], se=f.bse["group"], p=f.pvalues["group"]))
    o = pd.DataFrame(out); o["q"] = multipletests(o.p, method="fdr_bh")[1]
    return o.sort_values("p").reset_index(drop=True)
for covs in [["platelet"], ["erythrocyte", "platelet"]]:
    o = de_adj(covs); o.to_excel(w, sheet_name="D2_DE_adj_" + "_".join(covs)[:20], index=False)
    print(f"Dataset 2 adjusted for {covs}: q<0.05 = {(o.q < .05).sum()}, q<0.25 = {(o.q < .25).sum()}")
w.close(); print("->", os.path.join(OUT, "RevisionA2_results.xlsx"))
