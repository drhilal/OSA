"""Makale kalitesinde şekil üretimi. Tek sütun 89 mm, çift sütun 183 mm."""
import re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import stats
from sklearn.metrics import roc_curve

MM = 1 / 25.4
TEK, CIFT = 89 * MM, 183 * MM
GRUPLAR = ["Non-OSA", "Mild OSA", "Severe OSA"]
KISA = {"Non-OSA": "Non-OSA", "Mild OSA": "Mild", "Severe OSA": "Severe"}
SIRA = {"Non-OSA": 0, "Mild OSA": 1, "Severe OSA": 2}
RENK = {"Non-OSA": "#3B6EA5", "Mild OSA": "#E1A140", "Severe OSA": "#B33B3B"}
PANEL_RENK = "#B33B3B"
GRI = "#C9C9C9"

plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans", "Arial"],
    "font.size": 7, "axes.labelsize": 7, "axes.titlesize": 7.5,
    "xtick.labelsize": 6.5, "ytick.labelsize": 6.5, "legend.fontsize": 6.5,
    "axes.linewidth": .6, "xtick.major.width": .6, "ytick.major.width": .6,
    "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 300, "savefig.dpi": 600, "savefig.bbox": "tight",
    "savefig.pad_inches": 0.02, "pdf.fonttype": 42, "ps.fonttype": 42,
})


def _harf(ax, s, dx=-0.20, dy=1.06):
    ax.text(dx, dy, s, transform=ax.transAxes, fontsize=9, fontweight="bold",
            va="top", ha="left")


TIFF = False   # pipeline --tiff ile açılır (dergi talep ederse)


def _kaydet(fig, yol):
    fig.savefig(f"{yol}.pdf")          # vektörel, dergi tercihi
    fig.savefig(f"{yol}.png")          # hızlı önizleme
    if TIFF:
        fig.savefig(f"{yol}.tif", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)


def _jitter(ax, vals, grp, ylab, olcek=100, rng=None):
    rng = rng or np.random.default_rng(0)
    for i, l in enumerate(GRUPLAR):
        v = np.asarray(vals[(grp == l).values]) * olcek
        ax.scatter(rng.normal(i, .075, len(v)), v, s=9, color=RENK[l],
                   alpha=.85, linewidths=0, zorder=3)
        ax.hlines(v.mean(), i - .28, i + .28, color="k", lw=1.1, zorder=4)
        se = v.std(ddof=1) / np.sqrt(len(v))
        ax.vlines(i, v.mean() - se, v.mean() + se, color="k", lw=.8, zorder=4)
    ax.set_xticks(range(3))
    ax.set_xticklabels([KISA[l] for l in GRUPLAR])
    ax.set_xlim(-.55, 2.55)
    ax.set_ylabel(ylab)


# --------------------------------------------------------------- Şekil 1
def sekil1(idx_all, grp, yol):
    """Üç kalite panelinin OSA şiddetine göre dağılımı."""
    n = len(idx_all)
    fig, axes = plt.subplots(1, n, figsize=(CIFT, CIFT / n * 0.95))
    axes = np.atleast_1d(axes)
    baslik = {"erythrocyte": "Erythrocyte panel",
              "platelet": "Platelet panel",
              "coagulation": "Coagulation panel"}
    for j, (ax, (ad, (idx, hit))) in enumerate(zip(axes, idx_all.items())):
        _jitter(ax, idx, grp, "Contamination index (%)")
        rho, p = stats.spearmanr(grp.map(SIRA), idx)
        ps = "P < 0.001" if p < .001 else f"P = {p:.3f}"
        ax.set_title(f"{baslik.get(ad, ad)}  (n = {len(hit)})\n"
                     f"$\\rho$ = {rho:+.2f}, {ps}", pad=6)
        _harf(ax, "ABC"[j])
    fig.tight_layout(w_pad=2.0)
    _kaydet(fig, yol)


# --------------------------------------------------------------- Şekil 2
def sekil2(X, idx, grp, yol, hedef=("PRDX2", "CA1", "CAT"),
           kontrol=("HP", "HPX")):
    """Panel üyeleri indeksle örtüşüyor; haptoglobin tükenmiyor."""
    hedef = [h for h in hedef if h in X.columns]
    kontrol = [h for h in kontrol if h in X.columns]
    kol = hedef + kontrol
    fig, axes = plt.subplots(1, len(kol), figsize=(CIFT, CIFT / len(kol) * 1.05))
    axes = np.atleast_1d(axes)
    li = np.log2(idx)
    for j, (ax, h) in enumerate(zip(axes, kol)):
        ok = X[h].notna()
        for l in GRUPLAR:
            s = (ok & (grp == l)).values
            ax.scatter(li[s], X.loc[s, h], s=10, color=RENK[l], alpha=.85,
                       linewidths=0, zorder=3)
        r, p = stats.pearsonr(li[ok.values], X.loc[ok, h])
        b = np.polyfit(li[ok.values], X.loc[ok, h], 1)
        xs = np.linspace(li.min(), li.max(), 20)
        ax.plot(xs, np.polyval(b, xs), color="k", lw=.8, ls="--", zorder=2)
        ps = "P < 0.001" if p < .001 else f"P = {p:.3f}"
        tip = "panel member" if h in hedef else "in vivo haemolysis control"
        ax.set_title(f"{h}  ({tip})\nr = {r:+.2f}, {ps}", pad=6)
        ax.set_xlabel("log$_2$ erythrocyte index")
        ax.set_ylabel(f"log$_2$ {h}")
        _harf(ax, "ABCDE"[j])
    hnd = [Line2D([], [], marker="o", ls="", color=RENK[l], label=KISA[l], ms=3.5)
           for l in GRUPLAR]
    axes[-1].legend(handles=hnd, frameon=False, loc="best")
    fig.tight_layout(w_pad=1.8)
    _kaydet(fig, yol)


# --------------------------------------------------------------- Şekil 3
def sekil3(ham, ayarli, panel, yol, q_esik=.25, lfc_esik=.5):
    """Ham ve indekse ayarlı volkan grafikleri."""
    fig, axes = plt.subplots(1, 2, figsize=(CIFT, CIFT * .48), sharey=True)
    for j, (ax, (r, t)) in enumerate(zip(axes, [(ham, "Unadjusted"),
                                                ("", "")][:1]
                                        + [(ayarli, "Adjusted for erythrocyte index")])):
        inp = r.protein.isin(panel)
        ax.scatter(r.log2FC[~inp], -np.log10(r.p[~inp]), s=5, color=GRI,
                   linewidths=0, zorder=2)
        ax.scatter(r.log2FC[inp], -np.log10(r.p[inp]), s=16, color=PANEL_RENK,
                   edgecolor="k", lw=.25, zorder=4)
        sig = r[(r.q < q_esik) & (r.log2FC.abs() >= lfc_esik)]
        for _, w in sig.iterrows():
            ax.annotate(w.protein, (w.log2FC, -np.log10(w.p)), fontsize=4.8,
                        xytext=(2.2, 1.6), textcoords="offset points",
                        color=PANEL_RENK if w.protein in panel else "#333333")
        ax.axvline(0, color="k", lw=.4, zorder=1)
        for v in (-lfc_esik, lfc_esik):
            ax.axvline(v, color="k", lw=.4, ls=":", zorder=1)
        ax.set_title(t, pad=5)
        ax.set_xlabel("log$_2$ fold change (severe vs non-OSA)")
        _harf(ax, "AB"[j])
    axes[0].set_ylabel("$-$log$_{10}$ p")
    hnd = [Line2D([], [], marker="o", ls="", color=PANEL_RENK, ms=3.5,
                  markeredgecolor="k", markeredgewidth=.25,
                  label="Geyer erythrocyte panel"),
           Line2D([], [], marker="o", ls="", color=GRI, ms=3.0, label="other proteins")]
    axes[0].legend(handles=hnd, frameon=False, loc="upper left")
    fig.tight_layout(w_pad=1.5)
    _kaydet(fig, yol)


# --------------------------------------------------------------- Şekil 4
def sekil4(roc_in, y, yol):
    """ROC eğrileri ve AUROC karşılaştırması."""
    fig, axes = plt.subplots(1, 2, figsize=(CIFT, CIFT * .48))
    ax = axes[0]
    pal = ["#222222", "#3B6EA5", "#B33B3B", "#E1A140"]
    for (ad, (auc, sd, p)), c in zip(roc_in.items(), pal):
        fpr, tpr, _ = roc_curve(y, p)
        ax.plot(fpr, tpr, lw=1.2, color=c, label=f"{ad} — {auc:.3f}")
    ax.plot([0, 1], [0, 1], color="k", lw=.5, ls="--")
    ax.set_xlabel("1 $-$ specificity"); ax.set_ylabel("Sensitivity")
    ax.set_xlim(-.02, 1.02); ax.set_ylim(-.02, 1.02)
    ax.legend(frameon=False, loc="lower right", title="AUROC", title_fontsize=6.5)
    _harf(ax, "A")

    ax = axes[1]
    adlar = list(roc_in.keys())
    aucs = [roc_in[a][0] for a in adlar]
    sds = [roc_in[a][1] for a in adlar]
    yy = np.arange(len(adlar))[::-1]
    ax.barh(yy, aucs, xerr=sds, height=.6, color=pal[:len(adlar)],
            error_kw=dict(lw=.7, capsize=2), zorder=3)
    ax.axvline(.5, color="k", lw=.5, ls="--", zorder=2)
    ax.set_yticks(yy); ax.set_yticklabels(adlar)
    ax.set_xlim(.4, 1.02); ax.set_xlabel("AUROC")
    for v, t in zip(yy, aucs):
        ax.text(t + .012, v, f"{t:.3f}", va="center", fontsize=6)
    _harf(ax, "B", dx=-0.55)
    fig.tight_layout(w_pad=2.2)
    _kaydet(fig, yol)


# --------------------------------------------------------------- Şekil 5
def sekil5(skor, grp, duyarlilik, yol):
    """Ordinal konum ve duyarlılık analizi."""
    fig, axes = plt.subplots(1, 2, figsize=(CIFT, CIFT * .48))
    ax = axes[0]
    _jitter(ax, skor, grp, "Discriminant score", olcek=1)
    ax.axhline(0, color="k", lw=.4, ls=":")
    ax.set_title("Mild group held out of the model", pad=5)
    _harf(ax, "A")

    ax = axes[1]
    d = duyarlilik.iloc[::-1]
    yy = np.arange(len(d))
    ax.barh(yy, d.kat, height=.6, color="#3B6EA5", zorder=3)
    ax.axvline(1, color="k", lw=.5, ls="--", zorder=2)
    ax.set_yticks(yy); ax.set_yticklabels(d.varyant)
    ax.set_xlabel("Severe / non-OSA fold change")
    for v, (k, r_, p_) in zip(yy, zip(d.kat, d.ordinal_rho, d.ordinal_p)):
        ps = "P<0.001" if p_ < .001 else f"P={p_:.3f}"
        ax.text(k + .03, v, f"{k:.2f}x  ($\\rho$={r_:+.2f}, {ps})",
                va="center", fontsize=5.8)
    ax.set_xlim(0, max(d.kat) * 1.75)
    _harf(ax, "B", dx=-0.45)
    fig.tight_layout(w_pad=2.2)
    _kaydet(fig, yol)


# --------------------------------------------------------------- Şekil 6
def _kisalt(term, maxlen=54):
    """'GO_Biological_Process | Oxygen Transport (GO:0015671)' -> ('GO-BP', 'Oxygen Transport')"""
    kutup, _, ad = term.partition(" | ")
    if not ad:
        ad, kutup = term, ""
    etiket = {"GO_Biological_Process": "GO-BP", "GO_Molecular_Function": "GO-MF",
              "GO_Cellular_Component": "GO-CC", "KEGG": "KEGG",
              "Reactome": "Reactome"}.get(kutup.strip(), kutup.strip()[:8])
    ad = re.sub(r"\s*\((GO:\d+)\)$", "", ad)
    ad = re.sub(r"\s+R-HSA-\d+$", "", ad)
    if len(ad) > maxlen:
        ad = ad[:maxlen - 1].rstrip() + "…"
    return etiket, ad


def sekil6(ora_ham, ora_ayarli, yol, n=9, q_esik=.25):
    """Zenginleşen terimler ve onlara katkı veren proteinler."""
    h = ora_ham.drop_duplicates("yolak").set_index("yolak")
    a = ora_ayarli.drop_duplicates("yolak").set_index("yolak")

    sec = h[h.q < q_esik]
    if len(sec) < 3:
        sec = h.nsmallest(max(n, 3), "p")
    sec = sec.nsmallest(n, "p").iloc[::-1]          # en anlamlı üstte

    yy = np.arange(len(sec))
    yuk = max(TEK * .30, .30 * len(sec) + 1.00)
    fig, ax = plt.subplots(figsize=(CIFT, yuk))

    ham_v = -np.log10(sec.p.clip(lower=1e-300)).to_numpy()
    ax.barh(yy, ham_v, height=.62, color=PANEL_RENK, zorder=3,
            label="unadjusted (panel included)")

    # ayarlı: p=1 olanlar sıfır uzunlukta çıkar, bunları açık işaretle göster
    ayar_v, ns = [], []
    for t in sec.index:
        pv = a.loc[t, "p"] if t in a.index else 1.0
        v = -np.log10(min(max(pv, 1e-300), 1.0))
        ayar_v.append(v); ns.append(v < 0.02)
    ayar_v = np.array(ayar_v)
    ax.barh(yy, ayar_v, height=.62, color="#3B6EA5", zorder=4,
            label="adjusted for erythrocyte index")


    ax.axvline(-np.log10(.05), color="k", lw=.6, ls="--", zorder=2)
    ax.text(-np.log10(.05), -.62, " P = 0.05", fontsize=5.8, va="bottom")

    ax.set_yticks(yy)
    ax.set_yticklabels([_kisalt(t)[1] for t in sec.index], fontsize=6.4)
    for i, t in enumerate(sec.index):                      # kütüphane etiketi
        ax.text(-0.012, yy[i] - .30, _kisalt(t)[0], transform=ax.get_yaxis_transform(),
                ha="right", va="center", fontsize=5.2, color="#777777", style="italic")

    # çubuk ucuna katkı veren genler
    gen_txt = []
    for i, t in enumerate(sec.index):
        g = sec.loc[t, "genler"]
        g = "" if (not isinstance(g, str) or g == "nan") else g.replace(";", ", ")
        ov, sn = int(sec.loc[t, "kesisim_n"]), int(sec.loc[t, "set_n"])
        gen_txt.append(ax.text(ham_v[i] + ham_v.max() * .02, yy[i],
                               f"{g}  ({ov}/{sn})", va="center", fontsize=5.6,
                               color="#333333"))

    # Metin genişliği veri biriminde eksen sınırına bağlıdır; sabitlenene
    # kadar ölç-genişlet döngüsü kur (3 tur yeterli).
    xmax = ham_v.max() * 1.30
    for _ in range(4):
        ax.set_xlim(0, xmax)
        fig.canvas.draw()
        inv = ax.transData.inverted()
        sag = max(float(inv.transform(t.get_window_extent().corners())[:, 0].max())
                  for t in gen_txt)
        yeni = sag + xmax * .13
        if abs(yeni - xmax) < xmax * .005:
            xmax = yeni
            break
        xmax = yeni
    ax.set_xlim(0, xmax)

    for i, t in enumerate(sec.index):
        etiket = "n.s." if ns[i] else f"P = {a.loc[t, 'p']:.3f}"
        ax.text(xmax * .99, yy[i], etiket, va="center", ha="right",
                fontsize=5.6, color="#3B6EA5")
    ax.text(xmax * .99, len(sec) - .28, "adjusted", va="bottom", ha="right",
            fontsize=5.8, color="#3B6EA5", style="italic")

    ax.set_xlim(0, xmax); ax.set_ylim(-.75, len(sec) - .05)
    ax.set_xlabel("$-$log$_{10}$ P (Fisher exact test)")
    ax.legend(frameon=False, fontsize=6.2, ncol=2, loc="upper left",
              bbox_to_anchor=(0.0, -0.13), borderaxespad=0)
    fig.tight_layout()
    _kaydet(fig, yol)
