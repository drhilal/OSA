#!/usr/bin/env python3
"""
================================================================================
OSA plazma proteomiğinde örnek-kalitesi kaynaklı yanlılık
================================================================================
Veri  : PXD073409 — Müller MB ve ark., J Transl Med. 2026;24:777
Panel : Geyer PE ve ark., EMBO Mol Med. 2019;11:e10427, Table EV2 (PXD011749)

Hipotez: Yayımlanan "severe OSA'da sistemik oksidatif stres imzası" bulgusunun
önemli bir kısmı preanalitik eritrosit kontaminasyonuyla açıklanabilir.

Kullanım:
    python src/pipeline.py --matrix veri/<matris>.xlsx --panels veri/<EV2>.xlsx

Bkz. README.md
================================================================================
"""
import argparse, os, sys, warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import roc_auc_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from panels import load_panels
from genesets import ora, GENE_SETS
import figures as F

GRUPLAR = ["Non-OSA", "Mild OSA", "Severe OSA"]
SIRA = {"Non-OSA": 0, "Mild OSA": 1, "Severe OSA": 2}
MIN_GRUP = 10          # makale kriteri: grup başına >=10 ölçüm
Q_DEP, LFC_DEP = 0.25, 0.5


# ------------------------------------------------------------------ yardımcılar
def veri_yukle(path):
    lin = pd.read_excel(path, "Raw_Linear").set_index("Sample_ID")
    grp = lin.pop("Group")
    log = pd.read_excel(path, "AI_Input_Log2").set_index("Sample_ID")
    log.pop("Group")
    return lin.astype(float), log.astype(float), grp


def indeks(lin, genler):
    """Geyer tanımı: panel proteinlerinin toplam şiddeti / tüm proteinlerin toplamı."""
    hit = sorted(c for c in lin.columns if c in genler)
    if len(hit) < 3:
        return None, hit
    return lin[hit].sum(axis=1) / lin.sum(axis=1), hit


def grup_ist(idx, grp):
    g = [idx[(grp == l).values] for l in GRUPLAR]
    F_, p_a = stats.f_oneway(*g)
    rho, p_r = stats.spearmanr(grp.map(SIRA), idx)
    return dict(non_osa=g[0].mean(), mild=g[1].mean(), severe=g[2].mean(),
                kat=g[2].mean() / g[0].mean(), anova_F=F_, anova_p=p_a,
                ordinal_rho=rho, ordinal_p=p_r,
                severe_vs_non_p=stats.ttest_ind(g[2], g[0]).pvalue)


def diferansiyel(X, y, kovaryat=None, min_n=MIN_GRUP):
    kayit = []
    for c in X.columns:
        d = pd.DataFrame({"v": X[c], "y": y})
        if kovaryat is not None:
            d["k"] = kovaryat
        d = d.dropna()
        if d.y.sum() < min_n or (1 - d.y).sum() < min_n:
            continue
        lfc = d.loc[d.y == 1, "v"].mean() - d.loc[d.y == 0, "v"].mean()
        pred = ["y"] + (["k"] if kovaryat is not None else [])
        fit = sm.OLS(d.v, sm.add_constant(d[pred])).fit()
        kayit.append((c, lfc, fit.params["y"], fit.pvalues["y"]))
    r = pd.DataFrame(kayit, columns=["protein", "log2FC", "beta", "p"])
    r["q"] = multipletests(r.p, method="fdr_bh")[1]
    return r.sort_values("p").reset_index(drop=True)


def nested_auroc(M, y, seeds, pred=False):
    pipe = Pipeline([("imp", SimpleImputer(strategy="median")),
                     ("sc", StandardScaler()),
                     ("clf", LogisticRegression(C=0.1, max_iter=2000))])
    sk, pr = [], []
    for s in range(seeds):
        cv = StratifiedKFold(5, shuffle=True, random_state=s)
        p = cross_val_predict(pipe, M, y, cv=cv, method="predict_proba")[:, 1]
        sk.append(roc_auc_score(y, p)); pr.append(p)
    if pred:
        return float(np.mean(sk)), float(np.std(sk)), np.mean(pr, axis=0)
    return float(np.mean(sk)), float(np.std(sk))


def boot_ci(y, p, n=2000, seed=1):
    rng = np.random.default_rng(seed); bs = []
    for _ in range(n):
        i = rng.choice(len(y), len(y), replace=True)
        if len(set(y[i])) > 1:
            bs.append(roc_auc_score(y[i], p[i]))
    return float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))


def pf(p):
    return "< 0.001" if p < .001 else f"= {p:.3f}"


# ------------------------------------------------------------------ ana
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--matrix", required=True)
    ap.add_argument("--panels", required=True)
    ap.add_argument("--outdir", default="cikti")
    ap.add_argument("--seeds", type=int, default=20,
                    help="nested CV tekrarı (makale için 50 önerilir)")
    ap.add_argument("--tiff", action="store_true", help="ek olarak TIFF üret (dergi talebi)")
    ap.add_argument("--enrichr", action="store_true",
                    help="küratörlü setler yerine Enrichr kullan (internet gerekir)")
    a = ap.parse_args()

    F.TIFF = a.tiff
    T = os.path.join(a.outdir, "tables"); S = os.path.join(a.outdir, "figures")
    os.makedirs(T, exist_ok=True); os.makedirs(S, exist_ok=True)
    R = []
    def say(s=""):
        print(s); R.append(s)

    lin, X, grp = veri_yukle(a.matrix)
    pan = load_panels(a.panels)

    say("# Results\n")
    say(f"The dataset comprises {len(X)} samples "
        f"({', '.join(f'{l} n={int((grp==l).sum())}' for l in GRUPLAR)}) and "
        f"{X.shape[1]} protein groups, with {100*X.isna().mean().mean():.2f}% missing values.\n")

    # ---------------------------------------------------------- 1
    say("## 1. Quality marker indices across OSA severity\n")
    idx_all, oz = {}, []
    for ad, spec in pan.items():
        genler = spec["plasma_up"] or spec["genes"]
        ix, hit = indeks(lin, genler)
        if ix is None:
            say(f"- {ad}: only {len(hit)} members quantified; skipped."); continue
        idx_all[ad] = (ix, hit)
        d = grup_ist(ix, grp); d.update(panel=ad, n_protein=len(hit))
        oz.append(d)
    ozet = pd.DataFrame(oz).set_index("panel")
    ozet.to_csv(f"{T}/T1_contamination_indices.csv", encoding="utf-8-sig")
    say("| Panel | n | Non-OSA | Mild | Severe | Ratio | ANOVA P | rho | Trend P |")
    say("|---|---|---|---|---|---|---|---|---|")
    for ad, r in ozet.iterrows():
        say(f"| {ad} | {int(r.n_protein)} | {100*r.non_osa:.3f} | {100*r.mild:.3f} | "
            f"{100*r.severe:.3f} | {r.kat:.2f}× | {r.anova_p:.4f} | {r.ordinal_rho:+.2f} | "
            f"{r.ordinal_p:.5f} |")
    say("\nValues are percentages. The platelet and coagulation panels serve as "
        "negative controls: if only the erythrocyte index rises with severity, the "
        "finding is specific to erythrocyte lysis rather than to general sample "
        "degradation.\n")
    F.sekil1(idx_all, grp, f"{S}/Figure1_contamination_indices")

    ery = pan["erythrocyte"]["genes"]
    e_idx, e_hit = idx_all["erythrocyte"]
    say(f"The Geyer erythrocyte panel comprises 29 protein entries; because some "
        f"entries carry more than one gene symbol these correspond to {len(ery)} "
        f"symbols in total, of which {len(e_hit)} were quantified here: "
        f"{', '.join(e_hit)}.\n")
    fl = e_idx > (e_idx.mean() + 2 * e_idx.std())
    say(f"The sample-level flagging rule of Geyer et al. (mean + 2 SD) identified "
        f"{int(fl.sum())} sample(s) "
        f"({', '.join(f'#{i}' for i in e_idx.index[fl])}). That so few samples are "
        "flagged indicates the shift is systematic at the group level rather than "
        "driven by individual outliers.\n")
    F.sekil2(X, e_idx, grp, f"{S}/Figure2_index_correlations")

    # ---------------------------------------------------------- 2
    m = grp.isin(["Severe OSA", "Non-OSA"]).values
    Xs = X[m]; y = (grp[m] == "Severe OSA").astype(int).values
    ham = diferansiyel(Xs, y)
    ham.to_csv(f"{T}/T2_dep_unadjusted.csv", index=False, encoding="utf-8-sig")
    dep = ham[(ham.q < Q_DEP) & (ham.log2FC.abs() >= LFC_DEP)]
    up = dep[dep.log2FC > 0]
    inp = sorted(up.protein[up.protein.isin(ery)])
    say("## 2. Overlap with the published differential list\n")
    say(f"Applying the original criteria (FDR < {Q_DEP}, |log2FC| >= {LFC_DEP}) "
        f"recovered {len(dep)} differentially abundant proteins "
        f"({int((dep.log2FC>0).sum())} increased in severe OSA, "
        f"{int((dep.log2FC<0).sum())} decreased).\n")
    say(f"Of the {len(up)} proteins increased in severe OSA, **{len(inp)}** "
        f"({100*len(inp)/max(len(up),1):.0f}%) are members of the Geyer erythrocyte "
        f"panel: {', '.join(inp)}.\n")
    say(f"Non-panel proteins: {', '.join(sorted(up.protein[~up.protein.isin(ery)]))}.\n")

    # ---------------------------------------------------------- 3
    li = np.log2(e_idx); lim = li[m]
    nonp = [c for c in Xs.columns if c not in e_hit]
    ayarli_tam = diferansiyel(Xs, y, kovaryat=lim)
    ayarli = diferansiyel(Xs[nonp], y, kovaryat=lim)
    ayarli.to_csv(f"{T}/T3_dep_adjusted.csv", index=False, encoding="utf-8-sig")
    krs = ham[ham.protein.isin(nonp)].merge(ayarli, on="protein",
                                            suffixes=("_ham", "_ayarli"))
    krs["durum"] = np.where(krs.q_ayarli < Q_DEP, "kaldi", "kayboldu")
    krs.to_csv(f"{T}/T4_dep_comparison.csv", index=False, encoding="utf-8-sig")
    say("## 3. Adjustment for the erythrocyte index\n")
    say("Panel members were excluded and the log-transformed erythrocyte index was\n"
        "added as a covariate.\n")
    for e in (0.05, Q_DEP):
        say(f"- q < {e}: {int((krs.q_ham<e).sum())} -> {int((krs.q_ayarli<e).sum())} proteins")
    kal = krs[(krs.q_ham < Q_DEP) & (krs.q_ayarli < Q_DEP)].sort_values("p_ayarli")
    say(f"\n{len(kal)} proteins remained significant after adjustment (top 15):\n")
    say("| Protein | log2FC | q (unadjusted) | q (adjusted) |")
    say("|---|---|---|---|")
    for _, r in kal.head(15).iterrows():
        say(f"| {r.protein} | {r.log2FC_ham:+.3f} | {r.q_ham:.3f} | {r.q_ayarli:.3f} |")
    say("")
    F.sekil3(ham, ayarli_tam, ery, f"{S}/Figure3_volcano")

    # ---------------------------------------------------------- 4
    say("## 4. Source of classification performance\n")
    setler = {
        "All proteins": Xs.values,
        "Panel excluded": Xs[nonp].values,
        "Panel only": Xs[[c for c in e_hit if c in Xs.columns]].values,
        "Index only": lim.values.reshape(-1, 1),
    }
    roc_in, sat = {}, []
    for ad, M in setler.items():
        auc, sd, p = nested_auroc(M, y, a.seeds, pred=True)
        lo, hi = boot_ci(y, p)
        roc_in[ad] = (auc, sd, p)
        sat.append(dict(model=ad, auroc=auc, sd=sd, ci_alt=lo, ci_ust=hi))
    pd.DataFrame(sat).to_csv(f"{T}/T5_classification.csv", index=False, encoding="utf-8-sig")
    say("| Model | AUROC | SD | 95% CI |")
    say("|---|---|---|---|")
    for r in sat:
        say(f"| {r['model']} | {r['auroc']:.3f} | {r['sd']:.3f} | "
            f"{r['ci_alt']:.3f}–{r['ci_ust']:.3f} |")
    say(f"\nNested five-fold cross-validation with {a.seeds} repeats; confidence "
        "intervals from 2000 bootstrap resamples.\n")
    F.sekil4(roc_in, y, f"{S}/Figure4_roc")

    # ---------------------------------------------------------- 5
    say("## 5. Over-representation analysis\n")
    evren = list(ham.protein)
    hedef_ham = list(up.protein) + list(dep[dep.log2FC < 0].protein)
    dep_a = ayarli[(ayarli.q < Q_DEP) & (ayarli.log2FC.abs() >= LFC_DEP)]
    hedef_a = list(dep_a.protein)
    evren_a = [c for c in evren if c not in ery]
    if a.enrichr:
        try:
            from genesets import enrichr_ora
        except ImportError:
            sys.exit("HATA: --enrichr için gseapy gerekir.  pip install gseapy")
        say("Gene sets were taken from the Enrichr libraries (GO Biological Process,\n"
            "GO Molecular Function, KEGG, Reactome); statistics were computed locally\n"
            "with Fisher exact tests using the quantified proteome as background.\n")
        try:
            o_ham = enrichr_ora(hedef_ham, evren)
            o_ay = enrichr_ora(hedef_a, evren_a)
        except ModuleNotFoundError:
            sys.exit("HATA: gseapy kurulu değil.  pip install gseapy")
        except Exception as exc:
            sys.exit(f"HATA: Enrichr gen setleri indirilemedi "
                     f"({type(exc).__name__}: {exc}).\n"
                     "İnternet/proxy erişimini kontrol edin veya --enrichr "
                     "olmadan çalıştırın.")
    else:
        o_ham = ora(hedef_ham, evren)
        o_ay = ora(hedef_a, evren_a)
    o_ham.to_csv(f"{T}/T6_pathways_unadjusted.csv", index=False, encoding="utf-8-sig")
    o_ay.to_csv(f"{T}/T7_pathways_adjusted.csv", index=False, encoding="utf-8-sig")
    say(f"Target lists: {len(hedef_ham)} proteins unadjusted, {len(hedef_a)} adjusted. "
        f"Background: all tested proteins.\n")
    say("| Term | Set size | Unadjusted: overlap / P | Adjusted: overlap / P |")
    say("|---|---|---|---|")
    bir = o_ham.drop_duplicates("yolak").set_index("yolak")
    iki = o_ay.drop_duplicates("yolak").set_index("yolak")
    for yol in bir.sort_values("p").index[:10]:
        h = bir.loc[yol]
        s2 = "—"
        if yol in iki.index:
            aa = iki.loc[yol]
            s2 = f"{int(aa.kesisim_n)} / {aa.p:.4f}"
        kut, ad = F._kisalt(yol, maxlen=60)
        etiket = f"{ad} ({kut})" if kut else ad
        say(f"| {etiket} | {int(h.set_n)} | {int(h.kesisim_n)} / {h.p:.4f} | {s2} |")
    say("")
    if not a.enrichr:
        say("Gene sets are manually curated lists restricted to proteins observable "
            "in plasma (see `src/genesets.py`); they are not full GO/KEGG collections. "
            "They provide a targeted test of whether reported enrichments survive "
            "removal of panel members. Use `--enrichr` for genome-scale libraries.\n")
    F.sekil6(o_ham, o_ay, f"{S}/Figure6_pathways")

    # ---------------------------------------------------------- 6
    say("## 6. Sensitivity analysis\n")
    var = {"Full panel": e_hit,
           "Haemoglobin chains only": [c for c in ("HBA1", "HBB", "HBD") if c in lin.columns],
           "Non-haemoglobin members": [c for c in e_hit if c not in ("HBA1", "HBB", "HBD")]}
    vs = []
    for ad, cols in var.items():
        if len(cols) < 2:
            continue
        ix = lin[cols].sum(axis=1) / lin.sum(axis=1)
        d = grup_ist(ix, grp)
        vs.append(dict(varyant=ad, n=len(cols), kat=d["kat"],
                       ordinal_rho=d["ordinal_rho"], ordinal_p=d["ordinal_p"]))
    duy = pd.DataFrame(vs)
    duy.to_csv(f"{T}/T8_sensitivity.csv", index=False, encoding="utf-8-sig")
    say("| Panel definition | n | Ratio | rho | P |")
    say("|---|---|---|---|---|")
    for _, r in duy.iterrows():
        say(f"| {r.varyant} | {int(r.n)} | {r.kat:.2f}× | {r.ordinal_rho:+.2f} | {r.ordinal_p:.5f} |")
    say("")

    # ---------------------------------------------------------- 7
    say("## 7. Ordinal position of the held-out mild group\n")
    egit = grp.isin(["Severe OSA", "Non-OSA"]).values
    pipe = Pipeline([("imp", SimpleImputer(strategy="median")),
                     ("sc", StandardScaler()),
                     ("clf", LogisticRegression(C=0.1, max_iter=2000))])
    pipe.fit(X[egit].values, (grp[egit] == "Severe OSA").astype(int).values)
    skor = pd.Series(pipe.decision_function(X.values), index=X.index)
    skor.to_frame("skor").join(grp).to_csv(f"{T}/T9_ordinal_scores.csv", encoding="utf-8-sig")
    say("| Group | Score (mean +/- SD) | Model |")
    say("|---|---|---|")
    for l in GRUPLAR:
        v = skor[(grp == l).values]
        say(f"| {l} | {v.mean():+.2f} ± {v.std():.2f} | "
            f"{'in training' if l != 'Mild OSA' else '**held out**'} |")
    p_mn = stats.ttest_ind(skor[(grp == 'Mild OSA').values], skor[(grp == 'Non-OSA').values]).pvalue
    p_ms = stats.ttest_ind(skor[(grp == 'Mild OSA').values], skor[(grp == 'Severe OSA').values]).pvalue
    say(f"\nThe mild OSA group was not used to fit the model. Mild vs non-OSA P {pf(p_mn)}; "
        f"mild vs severe P {pf(p_ms)}. Non-OSA and severe scores are in-sample and "
        "therefore optimistic; only the intermediate position of the mild group is "
        "interpretable.\n")
    F.sekil5(skor, grp, duy, f"{S}/Figure5_ordinal_sensitivity")

    with open(os.path.join(a.outdir, "RESULTS.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(R) + "\n")
    print(f"\n-> {a.outdir}/RESULTS.md | {T}/ (9 tables) | {S}/ (6 figures)")


if __name__ == "__main__":
    main()
