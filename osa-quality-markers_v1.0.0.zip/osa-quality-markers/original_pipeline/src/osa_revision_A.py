"""
OSA plasma proteomics reanalysis (PXD073409) - Revision package A
==================================================================
Runs every additional analysis planned for the JCM resubmission:

  A1  Leave-one-protein-out (LOPO) erythrocyte index and panel-member correlations
  A2  Detection-filter sensitivity (50% / 70% / 80%)
  A3  Four analysis scenarios (DE + ORA with GO/KEGG/Reactome) -> main-text Table 3
  A4  Pre-ranked GSEA (all proteins vs panel excluded, unadjusted vs adjusted)
  A5  Classification: extra metrics, C sensitivity, PR-AUC, three-group OOF scores,
      non-OSA vs all-OSA and mild vs severe contrasts
  A6  Second dataset (PXD069503): erythrocyte index, OSA vs control, concordance of
      all adjustment-persistent proteins (forest plot, effect-size correlation),
      before/after index adjustment
  A7  Haptoglobin / hemopexin / CD163 vs index, overall and within groups

Outputs: RevisionA_results.xlsx (one sheet per analysis) + PNG figures in ./revA_out/

Inputs (edit CONFIG below):
  Dataset.xlsx   sheet OSA_plasma_proteome  (45 samples x 492 protein groups, linear)
                 sheet Geyer_quality_panels (Table EV2 of Geyer et al. 2019)
  PXD069503 Proteome Discoverer protein-level export (xlsx/csv)

Requirements: pandas numpy scipy statsmodels scikit-learn gseapy matplotlib openpyxl
Enrichr libraries are downloaded once by gseapy and cached (needs internet on first run).
"""

import warnings, os, re, itertools
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.metrics import (roc_auc_score, average_precision_score, roc_curve,
                             balanced_accuracy_score, confusion_matrix)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import gseapy as gp

warnings.filterwarnings("ignore")
RNG = np.random.default_rng(20260910)

# ============================== CONFIG ======================================
import sys, argparse
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)                      # so that panels.py / genesets.py import
_ap = argparse.ArgumentParser()
_ap.add_argument("--matrix", default=os.path.join(_HERE, "..", "veri", "PXD073409_OSA_AI_ready_matrix.xlsx"))
_ap.add_argument("--panels", default=os.path.join(_HERE, "..", "veri", "44321_2019_BFEMMM201910427_MOESM3_ESM.xlsx"))
_ap.add_argument("--second", default=os.path.join(_HERE, "..", "veri", "Proteins.xls"))
_ap.add_argument("--outdir", default=os.path.join(_HERE, "..", "cikti_revA"))
_ap.add_argument("--repeats", type=int, default=50)
_args, _ = _ap.parse_known_args()

CONFIG = dict(
    matrix_xlsx=_args.matrix,      # sheets Raw_Linear (index) and AI_Input_Log2 (stats), as in pipeline.py
    panels_xlsx=_args.panels,      # Geyer Table EV2, parsed by panels.load_panels
    # Second dataset (PXD069503, Proteome Discoverer protein-level export)
    second_dataset_path=_args.second,
    second_gene_col="Gene names",                       # Proteome Discoverer export column
    second_abundance_prefix="Abundances (Normalized)",  # 45 columns: "... Sample OSA_XJ_8" / "... Sample Con_XJ_3"
    second_osa_pattern=r"Sample OSA_",                  # regex on column names identifying OSA samples
    second_ctrl_pattern=r"Sample Con_",
    # Analysis settings
    detect_frac=0.70,
    min_valid_per_group=10,
    fdr_primary=0.05, fdr_exploratory=0.25, fc_thresh=0.5,
    libraries=["GO_Biological_Process_2023", "GO_Molecular_Function_2023",
               "KEGG_2021_Human", "Reactome_2022"],
    set_min=5, set_max=500,
    cv_repeats=_args.repeats, cv_folds=5, C_values=[0.01, 0.1, 1.0], C_main=0.1,
    n_boot=4000,
    outdir=_args.outdir,
)
os.makedirs(CONFIG["outdir"], exist_ok=True)
GROUP_ORDER = ["Non-OSA", "Mild", "Severe"]
GROUP_CODE = {g: i for i, g in enumerate(GROUP_ORDER)}

# Erythrocyte panel members quantified in PXD073409 (from manuscript Section 2.3)
ERY_QUANTIFIED = ["ACTB", "ALDOA", "BLVRB", "CA1", "CA2", "CAT", "GAPDH", "HBA1",
                  "HBB", "HBD", "LDHB", "PRDX2", "PRDX6", "SLC4A1", "UBB"]
HB_CHAINS = ["HBA1", "HBB", "HBD"]
OXIDATIVE_TERMS_RE = re.compile(
    r"(?i)hydrogen peroxide|reactive oxygen|oxidative|antioxidant|peroxid|oxygen transport|"
    r"gas transport|heme|haem|carbon dioxide|erythrocyte|one-carbon")

# ============================== LOADERS =====================================
def norm_group(g):
    g = str(g).strip().lower()
    if "non" in g or g in ("control", "ctrl", "0"): return "Non-OSA"
    if "mild" in g or g == "1": return "Mild"
    if "sev" in g or g == "2": return "Severe"
    raise ValueError(f"Unrecognised group label: {g}")

def load_primary():
    """Matrix as in pipeline.py: Raw_Linear (linear intensities, used for indices) and
    AI_Input_Log2 (log2 values, used for statistics). Both carry Sample_ID + Group."""
    lin = pd.read_excel(CONFIG["matrix_xlsx"], sheet_name="Raw_Linear").set_index("Sample_ID")
    groups = lin.pop("Group").map(norm_group)
    log = pd.read_excel(CONFIG["matrix_xlsx"], sheet_name="AI_Input_Log2").set_index("Sample_ID")
    log.pop("Group")
    lin = lin.astype(float).replace(0, np.nan); log = log.astype(float)
    lin.index = lin.index.astype(str); log.index = log.index.astype(str); groups.index = lin.index
    return lin, log, groups

def load_panels():
    """Uses the project's own panels.py (Geyer Table EV2 parser)."""
    from panels import load_panels as _lp
    pan = _lp(CONFIG["panels_xlsx"])
    return {k: sorted(v["genes"]) for k, v in pan.items()}

# ============================== HELPERS =====================================
def detect_filter(X, frac):
    keep = X.notna().mean(axis=0) >= frac
    return X.loc[:, keep]

def qm_index(X_lin, members, exclude=()):
    """Summed panel intensity / summed total intensity (linear), optionally excluding
    proteins from both numerator and denominator (LOPO)."""
    m = [p for p in members if p in X_lin.columns and p not in exclude]
    d = [c for c in X_lin.columns if c not in exclude]
    return X_lin[m].sum(axis=1) / X_lin[d].sum(axis=1)

def de_test(logX, groups, covariate=None, proteins=None, a="Severe", b="Non-OSA"):
    """OLS per protein: log2 abundance ~ group (+ covariate). Returns DataFrame."""
    sel = groups.isin([a, b])
    y_grp = (groups[sel] == a).astype(float)
    rows = []
    for p in (proteins if proteins is not None else logX.columns):
        v = logX.loc[sel, p]
        ok = v.notna()
        if (ok & (y_grp == 1)).sum() < CONFIG["min_valid_per_group"] or \
           (ok & (y_grp == 0)).sum() < CONFIG["min_valid_per_group"]:
            continue
        Xd = pd.DataFrame({"group": y_grp[ok]})
        if covariate is not None: Xd["cov"] = covariate[sel][ok]
        fit = sm.OLS(v[ok], sm.add_constant(Xd)).fit()
        rows.append(dict(protein=p, n=int(ok.sum()),
                         log2FC=v[ok][y_grp[ok] == 1].mean() - v[ok][y_grp[ok] == 0].mean(),
                         beta=fit.params["group"], se=fit.bse["group"], p=fit.pvalues["group"]))
    out = pd.DataFrame(rows)
    out["q"] = multipletests(out["p"], method="fdr_bh")[1]
    return out.sort_values("p").reset_index(drop=True)

_LIB_CACHE = {}
def get_gene_sets():
    if not _LIB_CACHE:
        for lib in CONFIG["libraries"]:
            for term, genes in gp.get_library(lib).items():
                _LIB_CACHE[f"{term} [{lib.split('_')[0]}]"] = set(genes)
    return _LIB_CACHE

def ora(hits, background):
    """One-sided Fisher ORA, background = quantified proteome, BH correction."""
    sets = get_gene_sets(); bg = set(background); hits = set(hits) & bg
    rows = []
    for term, genes in sets.items():
        g = genes & bg
        if not (CONFIG["set_min"] <= len(g) <= CONFIG["set_max"]): continue
        k = len(hits & g)
        if k == 0: continue
        table = [[k, len(hits) - k], [len(g) - k, len(bg) - len(hits) - len(g) + k]]
        odds, p = stats.fisher_exact(table, alternative="greater")
        rows.append(dict(term=term, set_size=len(g), overlap=k, odds=odds, p=p,
                         genes=";".join(sorted(hits & g))))
    cols = ["term", "set_size", "overlap", "odds", "p", "genes", "q"]
    if not rows: return pd.DataFrame(columns=cols)
    out = pd.DataFrame(rows); out["q"] = multipletests(out["p"], method="fdr_bh")[1]
    return out.sort_values("p").reset_index(drop=True)[cols]

def prerank(de, tag):
    """Pre-ranked GSEA on signed -log10(p) (sign = direction of beta)."""
    rnk = pd.Series((np.sign(de.beta) * -np.log10(de.p.clip(1e-300))).values, index=de.protein.astype(str).values)
    rnk = rnk[np.isfinite(rnk)].groupby(level=0).max().sort_values(ascending=False)
    rnk.index.name = None; rnk.name = None
    sets = {t: list(g) for t, g in get_gene_sets().items()}
    res = gp.prerank(rnk=rnk, gene_sets=sets, min_size=CONFIG["set_min"], max_size=CONFIG["set_max"],
                     permutation_num=2000, seed=1, threads=4, outdir=None, verbose=False).res2d
    res.insert(0, "analysis", tag)
    return res

def bootstrap_ci(stat_fn, n, B=None):
    B = B or CONFIG["n_boot"]; vals = []
    for _ in range(B):
        idx = RNG.integers(0, n, n)
        try: vals.append(stat_fn(idx))
        except ValueError: pass
    return np.nanpercentile(vals, [2.5, 97.5])

def cv_oof(X, y, C, groups_for_strat=None, score_extra=None):
    """Repeated stratified k-fold; returns averaged OOF probabilities for X rows,
    and (if score_extra given) averaged predictions for held-out extra samples."""
    rskf = RepeatedStratifiedKFold(n_splits=CONFIG["cv_folds"], n_repeats=CONFIG["cv_repeats"], random_state=0)
    oof = np.zeros((CONFIG["cv_repeats"], len(y))) * np.nan
    extra = [] if score_extra is not None else None
    for i, (tr, te) in enumerate(rskf.split(X, y)):
        rep = i // CONFIG["cv_folds"]
        pipe = Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler()),
                         ("lr", LogisticRegression(C=C, penalty="l2", max_iter=5000))])
        pipe.fit(X[tr], y[tr])
        oof[rep, te] = pipe.predict_proba(X[te])[:, 1]
        if extra is not None: extra.append(pipe.predict_proba(score_extra)[:, 1])
    return np.nanmean(oof, axis=0), (np.mean(extra, axis=0) if extra is not None else None)

def clf_metrics(y, p):
    fpr, tpr, thr = roc_curve(y, p); j = np.argmax(tpr - fpr)
    pred05 = (p >= 0.5).astype(int); predJ = (p >= thr[j]).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred05).ravel()
    return {"AUROC": roc_auc_score(y, p), "PR_AUC": average_precision_score(y, p),
            "sens_0.5": tp / (tp + fn), "spec_0.5": tn / (tn + fp),
            "bal_acc_0.5": balanced_accuracy_score(y, pred05),
            "bal_acc_youden": balanced_accuracy_score(y, predJ), "youden_thr": thr[j]}

# ============================== MAIN ========================================
def main():
    writer = pd.ExcelWriter(os.path.join(CONFIG["outdir"], "RevisionA_results.xlsx"), engine="openpyxl")
    LIN, LOG, groups = load_primary()
    panels = load_panels()
    print("Loaded matrix: linear", LIN.shape, "| log2", LOG.shape, "| groups:", groups.value_counts().to_dict())
    # Statistics use the log2 matrix filtered at >=70% detection (422 proteins expected);
    # indices use the full linear matrix as denominator, exactly as in pipeline.py.
    logX = detect_filter(LOG, CONFIG["detect_frac"]) if LOG.notna().mean().min() < CONFIG["detect_frac"] else LOG
    X = LIN                     # for index computation (all quantified proteins)
    X_all = LIN
    ery = [p for p in panels["erythrocyte"] if p in X.columns]
    ery_s = [p for p in ery if p in logX.columns]   # panel members present in the 422-protein stats matrix
    print(f"Stats matrix: {logX.shape[1]} proteins | Erythrocyte panel quantified: {len(ery)} -> {ery}")
    print(f"Panel members in stats matrix: {len(ery_s)} (missing: {sorted(set(ery) - set(ery_s))})")
    idx_full = qm_index(X, ery)
    log_idx = np.log2(idx_full)
    sev_code = groups.map(GROUP_CODE)

    # ---------------- A1: LOPO index ----------------
    rows = []
    for p in ery_s:
        idx_lopo = qm_index(X, ery, exclude=[p])
        lp = logX[p]; ok = lp.notna()
        r_full, p_full = stats.pearsonr(lp[ok], log_idx[ok])
        r_lopo, p_lopo = stats.pearsonr(lp[ok], np.log2(idx_lopo)[ok])
        rho_sev, p_sev = stats.spearmanr(idx_lopo, sev_code)
        rows.append(dict(protein=p, n=int(ok.sum()), r_vs_full_index=r_full, p_full=p_full,
                         r_vs_LOPO_index=r_lopo, p_LOPO=p_lopo,
                         share_of_panel_intensity=X[p].sum() / X[ery].sum().sum(),
                         LOPO_index_rho_vs_severity=rho_sev, p_rho=p_sev))
    A1 = pd.DataFrame(rows).sort_values("r_vs_LOPO_index", ascending=False)
    # Hb-free index vs each Hb chain (the strongest possible LOPO)
    idx_nohb = qm_index(X, ery, exclude=HB_CHAINS)
    for p in [h for h in HB_CHAINS if h in ery_s]:
        ok = logX[p].notna()
        A1.loc[A1.protein == p, "r_vs_index_without_all_Hb"] = stats.pearsonr(logX[p][ok], np.log2(idx_nohb)[ok])[0]
    A1.to_excel(writer, sheet_name="A1_LOPO_index", index=False); print(A1.round(3).to_string())

    # ---------------- A2: detection-filter sensitivity ----------------
    rows = []
    for frac in (0.50, 0.70, 0.80):
        lXf = detect_filter(LOG, frac)
        eryf = [p for p in panels["erythrocyte"] if p in X_all.columns]
        idxf = qm_index(X_all, eryf); rho, pr = stats.spearmanr(idxf, sev_code)
        de_u = de_test(lXf, groups); nonpanel = [p for p in lXf.columns if p not in eryf]
        de_a = de_test(lXf, groups, covariate=np.log2(idxf), proteins=nonpanel)
        rows.append(dict(detect_frac=frac, n_proteins=lXf.shape[1], n_panel_in_matrix=sum(p in lXf.columns for p in eryf),
                         index_rho_severity=rho, p=pr,
                         fold_severe_vs_non=idxf[groups == "Severe"].mean() / idxf[groups == "Non-OSA"].mean(),
                         n_tested_unadj=len(de_u), DE_q05_unadj=(de_u.q < .05).sum(), DE_q25_unadj=(de_u.q < .25).sum(),
                         DE_q25_FC_unadj=((de_u.q < .25) & (de_u.log2FC.abs() >= .5)).sum(),
                         n_tested_adj=len(de_a), DE_q05_adj=(de_a.q < .05).sum(), DE_q25_adj=(de_a.q < .25).sum(),
                         IGF1_q_adj=de_a.set_index("protein").q.get("IGF1", np.nan)))
    A2 = pd.DataFrame(rows); A2.to_excel(writer, sheet_name="A2_detection_filter", index=False); print(A2.round(3).to_string())

    # ---------------- A3: four scenarios ----------------
    nonpanel = [p for p in logX.columns if p not in ery]
    scen = {
        "A_all_unadjusted":        de_test(logX, groups),
        "B_panelexcl_unadjusted":  de_test(logX, groups, proteins=nonpanel),
        "C_panelexcl_adjusted":    de_test(logX, groups, covariate=log_idx, proteins=nonpanel),
        "D_all_adjusted":          de_test(logX, groups, covariate=log_idx),
    }
    ora_A = None; rows = []
    for name, de in scen.items():
        de.to_excel(writer, sheet_name=f"A3_DE_{name[:2]}", index=False)
        hits = de[(de.q < CONFIG["fdr_exploratory"]) & (de.log2FC.abs() >= CONFIG["fc_thresh"])].protein
        hits_up = de[(de.q < CONFIG["fdr_exploratory"]) & (de.log2FC >= CONFIG["fc_thresh"])].protein
        o = ora(hits, de.protein)
        o.to_excel(writer, sheet_name=f"A3_ORA_{name[:2]}", index=False)
        if ora_A is None: ora_A = o
        nine = ora_A[ora_A.q < .25].term.tolist() if len(ora_A) else []
        ov = o.set_index("term").overlap.reindex(nine).fillna(0).astype(int) if len(o) else pd.Series(0, index=nine)
        rows.append(dict(scenario=name, n_tested=len(de), q05=(de.q < .05).sum(), q25=(de.q < .25).sum(),
                         q25_FC=len(hits), q25_FC_up=len(hits_up),
                         n_hits_in_panel=hits.isin(ery).sum(),
                         terms_q25=(o.q < .25).sum() if len(o) else 0,
                         top_term=o.term.iloc[0] if len(o) else "", top_q=o.q.iloc[0] if len(o) else np.nan,
                         **{f"overlap|{t[:40]}": int(v) for t, v in ov.items()}))
    A3 = pd.DataFrame(rows); A3.to_excel(writer, sheet_name="A3_Table3_scenarios", index=False)
    try:   # cross-check scenario A with the project's own Enrichr ORA (genesets.py), if present
        from genesets import enrichr_ora
        deA = scen["A_all_unadjusted"]
        hitsA = deA[(deA.q < .25) & (deA.log2FC.abs() >= .5)].protein.tolist()
        enrichr_ora(hitsA, deA.protein.tolist()).rename(columns={"yolak": "term", "set_n": "set_size",
            "kesisim_n": "overlap", "genler": "genes"}).to_excel(writer, sheet_name="A3_ORA_A_genesets_py", index=False)
    except Exception as e:
        print("genesets.enrichr_ora cross-check skipped:", repr(e))
    print(A3.drop(columns=[c for c in A3.columns if c.startswith("overlap|")]).to_string())
    # Persisting proteins: in C at q<.25 AND in A at q<.25
    a_q = scen["A_all_unadjusted"].set_index("protein").q; c = scen["C_panelexcl_adjusted"].copy()
    c["q_unadjusted"] = c.protein.map(a_q); c["persisted_q25"] = (c.q < .25) & (c.q_unadjusted < .25)
    c["persisted_q05"] = (c.q < .05) & (c.q_unadjusted < .05)
    c.to_excel(writer, sheet_name="A3_persistence", index=False)
    persist25 = c[c.persisted_q25].protein.tolist()
    print(f"Persisting q<0.25: {len(persist25)} | q<0.05: {c.persisted_q05.sum()}")

    # ---------------- A4: pre-ranked GSEA ----------------
    gsea = pd.concat([prerank(scen["A_all_unadjusted"], "all_unadjusted"),
                      prerank(scen["B_panelexcl_unadjusted"], "panelexcl_unadjusted"),
                      prerank(scen["C_panelexcl_adjusted"], "panelexcl_adjusted"),
                      prerank(scen["D_all_adjusted"], "all_adjusted")])
    gsea.to_excel(writer, sheet_name="A4_GSEA_prerank", index=False)
    ox = gsea[gsea.Term.str.contains(OXIDATIVE_TERMS_RE)]
    ox.to_excel(writer, sheet_name="A4_GSEA_oxidative_terms", index=False)
    print(ox[["analysis", "Term", "NES", "FDR q-val"]].head(30).to_string())

    # ---------------- A5: classification ----------------
    ext = groups.isin(["Severe", "Non-OSA"]); y = (groups[ext] == "Severe").astype(int).values
    feats = {"all": list(logX.columns), "panel_excluded": nonpanel, "panel_only": ery_s,
             "index_only": ["__index__"]}
    M = logX.copy(); M["__index__"] = log_idx
    res, oofs = [], {}
    for C in CONFIG["C_values"]:
        for fname, cols in feats.items():
            p, _ = cv_oof(M.loc[ext, cols].values, y, C)
            oofs[(C, fname)] = p
            m = clf_metrics(y, p); m.update(C=C, feature_set=fname)
            m["AUROC_CI"] = "%.3f to %.3f" % tuple(bootstrap_ci(lambda i: roc_auc_score(y[i], p[i]), len(y), 2000))
            res.append(m)
    A5 = pd.DataFrame(res)[["C", "feature_set", "AUROC", "AUROC_CI", "PR_AUC", "sens_0.5", "spec_0.5",
                            "bal_acc_0.5", "bal_acc_youden", "youden_thr"]]
    A5.to_excel(writer, sheet_name="A5_classification", index=False); print(A5.round(3).to_string())
    # paired differences vs full model at C_main
    Cm = CONFIG["C_main"]; pf = oofs[(Cm, "all")]; rows = []
    for fname in ["panel_excluded", "panel_only", "index_only"]:
        po = oofs[(Cm, fname)]
        d = roc_auc_score(y, pf) - roc_auc_score(y, po)
        ci = bootstrap_ci(lambda i: roc_auc_score(y[i], pf[i]) - roc_auc_score(y[i], po[i]), len(y))
        rows.append(dict(comparison=f"all minus {fname}", diff_AUROC=d, ci_low=ci[0], ci_high=ci[1]))
    pd.DataFrame(rows).to_excel(writer, sheet_name="A5_paired_diffs", index=False); print(pd.DataFrame(rows).round(3))
    # Three-group: OOF for non-OSA/severe, mild scored by every fold model (never in training)
    mild = groups == "Mild"
    p_ext, p_mild = cv_oof(M.loc[ext, feats["all"]].values, y, Cm, score_extra=M.loc[mild, feats["all"]].values)
    sc = pd.concat([pd.Series(p_ext, index=groups[ext].index), pd.Series(p_mild, index=groups[mild].index)])
    A5b = pd.DataFrame({"sample": sc.index, "group": groups[sc.index].values, "oof_prob_severe": sc.values})
    rho, pr = stats.spearmanr(A5b.oof_prob_severe, A5b.group.map(GROUP_CODE))
    A5b.to_excel(writer, sheet_name="A5_threegroup_OOF", index=False)
    print(f"Three-group OOF score: Spearman rho vs severity = {rho:.3f}, P = {pr:.2g}")
    print(A5b.groupby("group").oof_prob_severe.describe().round(3))
    # Extra contrasts
    rows = [dict(contrast="three-group OOF score vs ordinal severity", rho=rho, p=pr)]
    for name, pos, neg in [("nonOSA_vs_allOSA", ["Mild", "Severe"], ["Non-OSA"]), ("mild_vs_severe", ["Severe"], ["Mild"])]:
        sel = groups.isin(pos + neg); yy = groups[sel].isin(pos).astype(int).values
        for fname in ["all", "panel_excluded", "index_only"]:
            pp, _ = cv_oof(M.loc[sel, feats[fname]].values, yy, Cm)
            rows.append(dict(contrast=name, feature_set=fname, AUROC=roc_auc_score(yy, pp),
                             AUROC_CI="%.3f to %.3f" % tuple(bootstrap_ci(lambda i: roc_auc_score(yy[i], pp[i]), len(yy), 2000)),
                             PR_AUC=average_precision_score(yy, pp)))
    pd.DataFrame(rows).to_excel(writer, sheet_name="A5_extra_contrasts", index=False); print(pd.DataFrame(rows).round(3).to_string())
    fig, ax = plt.subplots(figsize=(4, 3.5))
    for i, g in enumerate(GROUP_ORDER):
        v = A5b.oof_prob_severe[A5b.group == g]; ax.scatter(np.full(len(v), i) + RNG.normal(0, .06, len(v)), v, s=18)
        ax.hlines(v.mean(), i - .25, i + .25, color="k")
    ax.set_xticks(range(3)); ax.set_xticklabels(GROUP_ORDER); ax.set_ylabel("Out-of-fold P(severe)")
    ax.set_title(f"All 45 participants out-of-fold (rho = {rho:.2f})", fontsize=9); fig.tight_layout()
    fig.savefig(f"{CONFIG['outdir']}/FigA5_threegroup_oof.png", dpi=300); plt.close(fig)

    # ---------------- A7: haptoglobin & haemolysis markers ----------------
    rows = []
    for m in ["HP", "HPX", "CD163", "HPR", "HBA1", "PRDX2", "CA1"]:
        if m not in logX.columns: continue
        for gname, sel in [("all", groups.notna())] + [(g, groups == g) for g in GROUP_ORDER]:
            ok = sel & logX[m].notna()
            if ok.sum() < 6: continue
            r, p = stats.pearsonr(logX.loc[ok, m], log_idx[ok]); rs, ps = stats.spearmanr(logX.loc[ok, m], log_idx[ok])
            rows.append(dict(marker=m, subset=gname, n=int(ok.sum()), pearson_r=r, p=p, spearman_rho=rs, p_spearman=ps))
    A7 = pd.DataFrame(rows); A7.to_excel(writer, sheet_name="A7_haemolysis_markers", index=False); print(A7.round(3).to_string())

    # ---------------- A6: second dataset ----------------
    try:
        path = CONFIG["second_dataset_path"]
        if path.lower().endswith("xlsx"):
            d2 = pd.read_excel(path)
        else:   # PD "Proteins.xls" is a tab-separated text file despite the extension
            d2 = pd.read_csv(path, sep="\t", encoding="utf-8", encoding_errors="replace")
        gcol = CONFIG["second_gene_col"] or next(c for c in d2.columns if re.search(r"(?i)gene", str(c)))
        if CONFIG["second_abundance_prefix"]:
            acols = [c for c in d2.columns if str(c).startswith(CONFIG["second_abundance_prefix"])]
        else:
            acols = [c for c in d2.columns if re.search(CONFIG["second_osa_pattern"], str(c)) or
                     re.search(CONFIG["second_ctrl_pattern"], str(c))]
        d2 = d2[[gcol] + acols].copy()
        d2[gcol] = d2[gcol].astype(str).str.split(r"[;, ]").str[0].str.strip().replace({"HBA2": "HBA1"})
        d2 = d2[d2[gcol].ne("nan")].groupby(gcol)[acols].max()           # collapse duplicate symbols
        X2 = d2.T.apply(pd.to_numeric, errors="coerce").replace(0, np.nan)
        is_osa = pd.Series([bool(re.search(CONFIG["second_osa_pattern"], str(c))) and
                            not re.search(CONFIG["second_ctrl_pattern"], str(c)) for c in X2.index], index=X2.index)
        print(f"Second dataset: {X2.shape}, OSA={is_osa.sum()}, control={(~is_osa).sum()}")
        ery2 = [p for p in panels["erythrocyte"] if p in X2.columns]
        idx2 = qm_index(X2, ery2); lidx2 = np.log2(idx2)     # denominator = all quantified, as in dataset 1
        X2 = detect_filter(X2, CONFIG["detect_frac"]); lX2 = np.log2(X2)
        # index OSA vs control
        a, b = idx2[is_osa], idx2[~is_osa]
        A6a = pd.DataFrame([dict(n_panel_quantified=len(ery2), panel=";".join(ery2),
                                 index_mean_OSA=a.mean(), index_mean_control=b.mean(), fold=a.mean() / b.mean(),
                                 welch_p_log=stats.ttest_ind(np.log2(a), np.log2(b), equal_var=False).pvalue,
                                 mannwhitney_p=stats.mannwhitneyu(a, b).pvalue,
                                 AUROC_index=roc_auc_score(is_osa.astype(int), idx2))])
        A6a.to_excel(writer, sheet_name="A6_index_dataset2", index=False); print(A6a.round(4).to_string())
        # DE in dataset 2, unadjusted and index-adjusted
        g2 = pd.Series(np.where(is_osa, "Severe", "Non-OSA"), index=X2.index)   # reuse OLS helper labels
        de2_u = de_test(lX2, g2); de2_a = de_test(lX2, g2, covariate=lidx2, proteins=[p for p in lX2.columns if p not in ery2])
        de2_u.to_excel(writer, sheet_name="A6_DE2_unadjusted", index=False); de2_a.to_excel(writer, sheet_name="A6_DE2_adjusted", index=False)
        # concordance of adjustment-persistent proteins (primary scenario C, q<.25)
        cC = scen["C_panelexcl_adjusted"].set_index("protein")
        target = persist25 if len(persist25) >= 3 else cC[cC.q < .25].index.tolist()
        comp = pd.DataFrame({"protein": target})
        comp["beta_primary"] = comp.protein.map(cC.beta); comp["se_primary"] = comp.protein.map(cC.se)
        comp["q_primary_adj"] = comp.protein.map(cC.q)
        for tag, de2 in [("d2_unadj", de2_u), ("d2_adj", de2_a)]:
            s = de2.set_index("protein")
            comp[f"beta_{tag}"] = comp.protein.map(s.beta); comp[f"se_{tag}"] = comp.protein.map(s.se)
            comp[f"p_{tag}"] = comp.protein.map(s.p); comp[f"q_{tag}"] = comp.protein.map(s.q)
        comp = comp.dropna(subset=["beta_d2_unadj"])
        comp["same_direction_unadj"] = np.sign(comp.beta_primary) == np.sign(comp.beta_d2_unadj)
        comp["same_direction_adj"] = np.sign(comp.beta_primary) == np.sign(comp.beta_d2_adj)
        comp.to_excel(writer, sheet_name="A6_concordance", index=False)
        k, n = comp.same_direction_unadj.sum(), len(comp)
        rho_es, p_es = stats.spearmanr(comp.beta_primary, comp.beta_d2_unadj)
        r_es, pr_es = stats.pearsonr(comp.beta_primary, comp.beta_d2_unadj)
        summ = pd.DataFrame([dict(n_persistent_primary=len(persist25), n_quantified_in_d2=n,
                                  same_direction=k, binomial_p=stats.binomtest(k, n, .5).pvalue,
                                  effect_size_spearman=rho_es, p=p_es, effect_size_pearson=r_es, p_pearson=pr_es,
                                  same_direction_after_index_adj_d2=int(comp.same_direction_adj.sum()),
                                  n_sig_q05_d2=int((comp.q_d2_unadj < .05).sum()))])
        summ.to_excel(writer, sheet_name="A6_concordance_summary", index=False); print(summ.round(4).to_string())
        # forest plot
        cp = comp.sort_values("beta_primary"); yy = np.arange(len(cp))
        fig, ax = plt.subplots(figsize=(6, 0.28 * len(cp) + 1.5))
        ax.errorbar(cp.beta_primary, yy + .18, xerr=1.96 * cp.se_primary, fmt="o", ms=4, label="PXD073409 (severe vs non-OSA, index-adjusted)")
        ax.errorbar(cp.beta_d2_unadj, yy - .18, xerr=1.96 * cp.se_d2_unadj, fmt="s", ms=4, label="PXD069503 (OSA vs control)")
        ax.axvline(0, color="grey", lw=.8); ax.set_yticks(yy); ax.set_yticklabels(cp.protein, fontsize=7)
        ax.set_xlabel("log2 difference (95% CI)"); ax.legend(fontsize=7, loc="lower right"); fig.tight_layout()
        fig.savefig(f"{CONFIG['outdir']}/FigA6_forest.png", dpi=300); plt.close(fig)
        # panel block & haptoglobin in dataset 2
        rows = []
        for m in ery2 + [x for x in ["HP", "HPX", "CD163"] if x in lX2.columns]:
            ok = lX2[m].notna()
            r, p = stats.pearsonr(lX2.loc[ok, m], lidx2[ok]); rows.append(dict(protein=m, in_panel=m in ery2, r_vs_index=r, p=p))
        pd.DataFrame(rows).to_excel(writer, sheet_name="A6_panel_block_d2", index=False)
    except FileNotFoundError as e:
        print("A6 skipped - second dataset file not found:", e)
    except Exception as e:
        import traceback; print("A6 stopped early:", repr(e)); traceback.print_exc()

    writer.close()
    print("\nDone ->", os.path.join(CONFIG["outdir"], "RevisionA_results.xlsx"))

if __name__ == "__main__":
    main()
