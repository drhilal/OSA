"""
Geyer 2019 (EMBO Mol Med 11:e10427) Table EV2 kalite belirteci panellerini okur.

Panel tanımları:
  - Eritrosit  : 30 protein, NIF3L1 makalede panelden çıkarılmış -> 29
  - Trombosit  : 30 protein, F13A1 makalede panelden çıkarılmış  -> 29
  - Pıhtılaşma : 31 protein. İndeks YALNIZCA plazmada artan
                 (T-test farkı > 0) proteinlerden hesaplanır.
"""
import pandas as pd

# Table EV2 içindeki satır aralıkları (0-tabanlı, header=None ile okunduğunda)
_ROWS = {"erythrocyte": (9, 39), "platelet": (47, 77), "coagulation": (88, 119)}
_EXCLUDED = {"erythrocyte": {"NIF3L1"}, "platelet": {"F13A1"}, "coagulation": set()}


def load_panels(ev2_path, sheet="Table EV2"):
    """Üç paneli döndürür: {panel_adi: {'genes': set, 'plasma_up': set|None}}"""
    d = pd.read_excel(ev2_path, sheet, header=None)
    out = {}
    for name, (lo, hi) in _ROWS.items():
        genes, plasma_up = set(), set()
        for i in range(lo, hi):
            raw = str(d.iloc[i, 2]).strip()
            if raw in ("nan", ""):
                continue
            members = {g for g in raw.split(";") if g}
            members -= _EXCLUDED[name]
            if not members:
                continue
            genes |= members
            if name == "coagulation":
                try:
                    if float(d.iloc[i, 6]) > 0:      # plazmada artan
                        plasma_up |= members
                except (TypeError, ValueError):
                    pass
        out[name] = {"genes": genes, "plasma_up": plasma_up or None}
    return out


if __name__ == "__main__":
    import sys
    for k, v in load_panels(sys.argv[1]).items():
        extra = ""
        if v["plasma_up"]:
            extra = f" (indeks için plazmada artan: {len(v['plasma_up'])})"
        print(f"{k:12s} {len(v['genes']):3d} gen{extra}")
