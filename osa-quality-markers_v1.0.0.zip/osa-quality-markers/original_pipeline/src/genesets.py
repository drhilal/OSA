"""
Plazma proteomiği için küratörlü gen setleri ve aşırı-temsil analizi (ORA).

NOT: Bunlar tam GO/KEGG setleri değildir. Plazma proteomunda gözlenebilen
üyelerle sınırlı, elle küratörlenmiş setlerdir. Amaç, yayımlanan çalışmanın
bildirdiği yolak zenginleşmelerinin eritrosit paneli çıkarıldığında ayakta kalıp
kalmadığını hedefli biçimde test etmektir. Metotlarda böyle tanımlanmalıdır.

Tam genom ölçekli analiz için --enrichr bayrağı kullanılabilir (internet gerekir).
"""
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

GENE_SETS = {
    "Antioxidant activity": {
        "CAT", "GPX3", "GPX1", "PRDX1", "PRDX2", "PRDX4", "PRDX6", "SOD1",
        "SOD2", "SOD3", "TXN", "TXNDC5", "GSR", "HP", "HPX", "CP", "MT2A",
    },
    "Oxygen and gas transport": {
        "HBA1", "HBA2", "HBB", "HBD", "HBG1", "HBG2", "HBE1", "CA1", "CA2",
        "AHSP", "MB",
    },
    "Erythrocyte structural proteins": {
        "SLC4A1", "SPTA1", "SPTB", "ANK1", "EPB41", "EPB42", "GYPA", "RHAG",
        "ADD1", "DMTN",
    },
    "Glycolysis": {
        "ALDOA", "ALDOB", "ALDOC", "ENO1", "ENO2", "GAPDH", "GPI", "HK1",
        "LDHA", "LDHB", "PFKL", "PFKM", "PGAM1", "PGK1", "PKM", "TPI1", "BPGM",
    },
    "Complement activation": {
        "C1QA", "C1QB", "C1QC", "C1R", "C1S", "C1RL", "C2", "C3", "C4A", "C4B",
        "C4BPA", "C4BPB", "C5", "C6", "C7", "C8A", "C8B", "C8G", "C9", "CFB",
        "CFD", "CFH", "CFHR1", "CFI", "CFP", "MASP1", "MASP2", "MBL2",
        "SERPING1", "CLU", "VTN", "FCN2", "FCN3",
    },
    "Coagulation and fibrinolysis": {
        "F2", "F5", "F7", "F9", "F10", "F11", "F12", "F13A1", "F13B", "FGA",
        "FGB", "FGG", "SERPINC1", "SERPIND1", "SERPINF2", "SERPINA5", "PROC",
        "PROS1", "PLG", "VWF", "KNG1", "KLKB1", "THBS1", "GP1BA", "GP5",
        "PLAT", "SERPINE1", "HRG", "A2M",
    },
    "Acute phase response": {
        "CRP", "SAA1", "SAA2", "SAA4", "HP", "HPX", "SERPINA1", "SERPINA3",
        "ORM1", "ORM2", "LBP", "ITIH3", "ITIH4", "A2M", "TF", "CP", "FGA",
        "FGB", "FGG", "AGT", "APCS", "LGALS3BP",
    },
    "Lipoprotein and cholesterol transport": {
        "APOA1", "APOA2", "APOA4", "APOB", "APOC1", "APOC2", "APOC3", "APOD",
        "APOE", "APOF", "APOM", "APOL1", "LCAT", "CETP", "PLTP", "PON1",
        "PON3", "SAA4",
    },
    "IGF transport and regulation": {
        "IGF1", "IGF2", "IGFBP1", "IGFBP2", "IGFBP3", "IGFBP4", "IGFBP5",
        "IGFBP6", "IGFBP7", "IGFALS",
    },
    "Extracellular matrix organisation": {
        "COL1A1", "COL1A2", "COL6A1", "FBLN1", "FBLN5", "FN1", "LUM", "MGP",
        "PRG4", "SPARC", "TNXB", "HSPG2", "MMP2", "MMP9", "TIMP1", "LTBP1",
    },
    "Platelet degranulation": {
        "PF4", "PPBP", "THBS1", "TLN1", "FLNA", "MYH9", "ACTN1", "VCL", "PFN1",
        "TAGLN2", "SPARC", "ITGA2B", "ITGB3", "MMRN1", "SRGN", "CFL1",
    },
}


def ora(hedef, evren, gene_sets=None, min_kesisim=2):
    """
    Aşırı-temsil analizi (Fisher kesin testi, tek yönlü, BH-FDR).

    hedef  : ilgilenilen protein listesi (ör. DEP'ler)
    evren  : test edilen tüm proteinler (arka plan)
    """
    gene_sets = gene_sets or GENE_SETS
    hedef, evren = set(hedef) & set(evren), set(evren)
    kayit = []
    for ad, uyeler in gene_sets.items():
        u = uyeler & evren
        if len(u) < 3:
            continue
        k = hedef & u
        if len(k) < min_kesisim:
            kayit.append((ad, len(u), len(k), np.nan, 1.0, ""))
            continue
        tablo = [[len(k), len(hedef) - len(k)],
                 [len(u) - len(k), len(evren) - len(hedef) - len(u) + len(k)]]
        odds, p = stats.fisher_exact(tablo, alternative="greater")
        kayit.append((ad, len(u), len(k), odds, p, ";".join(sorted(k))))
    r = pd.DataFrame(kayit, columns=["yolak", "set_n", "kesisim_n", "odds", "p", "genler"])
    r["q"] = multipletests(r.p.fillna(1.0), method="fdr_bh")[1]
    return r.sort_values("p").reset_index(drop=True)


def enrichr_ora(hedef, evren, kutuphaneler=None, min_set=5, max_set=500,
                onek=True):
    """
    Tam GO/KEGG analizi. Kütüphaneler Enrichr'dan indirilir, istatistik ise
    yerelde bu modülün ora() fonksiyonuyla yürütülür.

    Bu yaklaşımın nedeni: arka plan (evren) bizim kontrolümüzde kalır ve çıktı
    küratörlü analizle birebir aynı şemayı taşır.

    Gerekli: `pip install gseapy` + internet erişimi.
    Çıktı: yolak | set_n | kesisim_n | odds | p | q | genler
    """
    import gseapy as gp

    kutuphaneler = kutuphaneler or [
        "GO_Biological_Process_2023",
        "GO_Molecular_Function_2023",
        "KEGG_2021_Human",
        "Reactome_2022",
    ]
    setler = {}
    for lib in kutuphaneler:
        try:
            d = gp.get_library(name=lib, organism="Human")
        except Exception as exc:
            print(f"  UYARI: {lib} indirilemedi ({type(exc).__name__}); atlandı.")
            continue
        kisa = lib.replace("_2023", "").replace("_2022", "").replace("_2021_Human", "")
        for term, genler in d.items():
            g = {x.strip().upper() for x in genler if x}
            if min_set <= len(g) <= max_set:
                ad = f"{kisa} | {term}" if onek else term
                setler[ad] = g
    if not setler:
        raise RuntimeError("Hiçbir gen seti indirilemedi; internet erişimini kontrol edin.")
    print(f"  {len(setler)} gen seti indirildi ({len(kutuphaneler)} kütüphane).")

    hedef = {g.upper() for g in hedef}
    evren = {g.upper() for g in evren}
    return ora(hedef, evren, gene_sets=setler, min_kesisim=2)
