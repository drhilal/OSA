"""Tables S2-S4, S11b, differential counts of Table 2 and Figure 5 (PXD073409, severe vs non-OSA)."""
import sys; from pathlib import Path; sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
import common as c

M, grp = c.load_primary()
ERY = c.quantified_members(c.geyer_panels()["erythrocyte"], M.columns)
keep = list(M.columns[M.notna().mean() >= 0.7])                     # 70% detection: 422 proteins
sel = grp.isin(["Severe OSA", "Non-OSA"]).values
x = (grp[sel] == "Severe OSA").astype(float).values
L = np.log2(M.loc[sel, keep])
full = np.log2(c.index(M, ERY)[sel]).values
cache = {}
def lopo(hb_free):
    def f(p):
        if p not in ERY:
            return full
        excl = tuple(c.HB) if (hb_free and p in c.HB) else (p,)
        if excl not in cache:
            cache[excl] = np.log2(c.index(M, ERY, exclude=excl)[sel]).values
        return cache[excl]
    return f
nonpanel = [p for p in keep if p not in ERY]
S = {"A": c.differential(L, x, keep),
     "B": c.differential(L, x, nonpanel),
     "C": c.differential(L, x, nonpanel, lambda p: full),
     "D": c.differential(L, x, keep, lambda p: full),
     "D1": c.differential(L, x, keep, lopo(False)),
     "D2": c.differential(L, x, keep, lopo(True))}
counts = []
for k, d in S.items():
    lst = d[(d.q < 0.25) & (d.log2FC.abs() >= 0.5)].Protein.tolist()
    d.to_csv(c.RESULTS / f"DE_scenario_{k}.csv", index=False)
    pd.Series(lst, name="Protein").to_csv(c.RESULTS / f"DE_list_scenario_{k}.csv", index=False)
    counts.append({"Scenario": k, "Proteins tested": len(d), "q < 0.05": int((d.q < 0.05).sum()),
                   "q < 0.25": int((d.q < 0.25).sum()), "q < 0.25 and |log2FC| >= 0.5": len(lst)})
pd.DataFrame(counts).to_csv(c.RESULTS / "Table2_differential_counts.csv", index=False)
S["A"].sort_values("p").to_csv(c.RESULTS / "S2_DEP_unadjusted.csv", index=False)
S["C"].sort_values("p").to_csv(c.RESULTS / "S3_DEP_adjusted.csv", index=False)
a, cc = S["A"].set_index("Protein"), S["C"].set_index("Protein")
s4 = pd.DataFrame({"Protein": cc.index, "log2FC (unadjusted)": a.loc[cc.index, "log2FC"].values,
                   "q (unadjusted)": a.loc[cc.index, "q"].values, "beta (adjusted)": cc.beta.values,
                   "CI lower": cc["CI lower"].values, "CI upper": cc["CI upper"].values, "q (adjusted)": cc.q.values})
s4["Status (q < 0.25)"] = np.select(
    [(s4["q (unadjusted)"] < .25) & (s4["q (adjusted)"] < .25), s4["q (unadjusted)"] < .25, s4["q (adjusted)"] < .25],
    ["persisted", "lost after adjustment", "emerged after adjustment"], "not significant")
s4.sort_values("q (adjusted)").to_csv(c.RESULTS / "S4_DEP_comparison.csv", index=False)
s11b = S["D1"][["Protein", "log2FC", "beta", "SE", "p", "q"]].merge(
    S["D2"][["Protein", "beta", "SE", "p", "q"]], on="Protein", suffixes=(" D1", " D2"))
s11b.insert(1, "Erythrocyte panel", s11b.Protein.isin(ERY))
s11b.sort_values("p D2").to_csv(c.RESULTS / "S11b_DEP_scenario_D_LOPO.csv", index=False)

from adjustText import adjust_text
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, axs = plt.subplots(1, 2, figsize=(13, 5.6), dpi=300, sharey=True)
for k, (ax, d, xcol, title) in enumerate(zip(axs, [S["A"], S["C"]], ["log2FC", "beta"],
        ["Unadjusted (all proteins)", "Adjusted for the erythrocyte index (panel members excluded)"])):
    pan = d.Protein.isin(ERY)
    ax.scatter(d[xcol][~pan], -np.log10(d.p[~pan]), s=9, color="#BBBBBB", label="other proteins")
    if pan.any():
        ax.scatter(d[xcol][pan], -np.log10(d.p[pan]), s=36, color="#C0504D", edgecolor="black", lw=0.5,
                   label="erythrocyte panel member", zorder=3)
    for v in (-0.5, 0.5): ax.axvline(v, ls=":", color="black", lw=0.8)
    ax.axvline(0, color="black", lw=0.6)
    lab = d[(d.q < 0.25) & (d[xcol].abs() >= 0.5)]
    texts = [ax.text(r[xcol], -np.log10(r.p), r.Protein, fontsize=7.5,
                     color="#C0504D" if r.Protein in ERY else "#333") for _, r in lab.iterrows()]
    adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle="-", color="grey", lw=0.5))
    ax.set_xlabel("log$_2$ fold change (severe vs non-OSA)" if k == 0 else "adjusted log$_2$ difference (severe vs non-OSA)")
    ax.set_title(title, fontsize=11); ax.text(-0.08, 1.03, "AB"[k], transform=ax.transAxes, fontsize=15, fontweight="bold")
axs[0].set_ylabel("-log$_{10}$ P"); axs[0].legend(frameon=False, fontsize=8, loc="upper left")
fig.tight_layout(); fig.savefig(c.RESULTS / "Figure5.png", dpi=300, facecolor="white", bbox_inches="tight")
print(pd.DataFrame(counts).to_string(index=False))
