"""Table S1 and Figure 1: quality marker indices in PXD073409."""
import sys; from pathlib import Path; sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy import stats
import common as c

M, grp = c.load_primary()
P = c.geyer_panels()
order = {"Non-OSA": 0, "Mild OSA": 1, "Severe OSA": 2}
rng = np.random.default_rng(c.SEED)
rows, idx = [], {}
for panel, entries in P.items():
    mem = c.quantified_members(entries, M.columns)
    v = c.index(M, mem); idx[panel] = (v, len(mem))
    G = {k: v[grp == k].values for k in order}
    r = {"Panel": panel, "Members quantified": len(mem)}
    r.update({f"Index, {k}": G[k].mean() for k in G})
    r["ANOVA (log scale) p"] = stats.f_oneway(*[np.log(x) for x in G.values()]).pvalue
    r["Kruskal-Wallis p"] = stats.kruskal(*G.values()).pvalue
    r["Spearman rho"], r["Spearman p"] = stats.spearmanr(grp.map(order), v)
    for a, b, lab in [("Mild OSA", "Non-OSA", "mild/non-OSA"), ("Severe OSA", "Non-OSA", "severe/non-OSA"),
                      ("Severe OSA", "Mild OSA", "severe/mild")]:
        e, lo, hi = c.gmr(G[a], G[b], rng)
        r[f"GMR {lab}"], r[f"GMR {lab} 95% CI lower"], r[f"GMR {lab} 95% CI upper"] = e, lo, hi
        r[f"Welch p (log) {lab}"] = stats.ttest_ind(np.log(G[a]), np.log(G[b]), equal_var=False).pvalue
    rows.append(r)
pd.DataFrame(rows).to_csv(c.RESULTS / "S1_Quality_indices.csv", index=False)

col = {"Non-OSA": "#4C78A8", "Mild OSA": "#E3A23B", "Severe OSA": "#C0504D"}
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, axs = plt.subplots(1, 3, figsize=(13, 4.2), dpi=300)
jit = np.random.default_rng(5)
for k, (ax, (panel, (v, n))) in enumerate(zip(axs, idx.items())):
    v = v * 100
    for j, g in enumerate(order):
        vv = v[grp == g].values
        ax.scatter(j + jit.uniform(-0.15, 0.15, len(vv)), vv, s=16, color=col[g], zorder=2)
        m, se = vv.mean(), vv.std(ddof=1) / np.sqrt(len(vv))
        ax.hlines(m, j - 0.25, j + 0.25, color="black", lw=1.6, zorder=3)
        ax.vlines(j, m - se, m + se, color="black", lw=1.2, zorder=3)
    rho, pv = stats.spearmanr(grp.map(order), v)
    ptxt = "P < 0.001" if pv < 0.001 else f"P = {pv:.3f}"
    ax.set_title(f"{panel.capitalize()} panel  (n = {n})\nrho = {rho:+.2f}, {ptxt}", fontsize=11)
    ax.set_xticks([0, 1, 2]); ax.set_xticklabels(["Non-OSA", "Mild", "Severe"])
    ax.set_ylabel("Quality marker index (%)")
    ax.text(-0.15, 1.05, "ABC"[k], transform=ax.transAxes, fontsize=15, fontweight="bold")
fig.tight_layout(); fig.savefig(c.RESULTS / "Figure1.png", dpi=300, facecolor="white", bbox_inches="tight")
print("Table S1 and Figure 1 written")
