"""Over-representation analysis for scenarios A-D2 (Tables S6, S9-S11, S11c; Table 2) and Figure 3."""
import sys; from pathlib import Path; sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
import common as c

background = {"A": 420, "B": 409, "C": 409, "D": 420, "D1": 420, "D2": 420}
res, summary = {}, []
for k, n in background.items():
    lst = pd.read_csv(c.RESULTS / f"DE_list_scenario_{k}.csv").Protein.tolist()
    o = c.ora(lst, n); res[k] = o
    o[o.Overlap >= 2].to_csv(c.RESULTS / f"ORA_scenario_{k}.csv", index=False)
    summary.append({"Scenario": k, "List size": len(lst), "Terms at q < 0.25": int((o.q < 0.25).sum())})
nine = res["A"][res["A"].q < 0.25].Term.tolist()
pd.DataFrame(summary).to_csv(c.RESULTS / "Table2_enrichment_counts.csv", index=False)

A = res["A"].set_index("Term").loc[nine].iloc[::-1]; D2 = res["D2"].set_index("Term")
nice = lambda t: (t.split(" | ")[1] if " | " in t else t).replace(" R-HSA-", " (R-HSA-") + (")" if "R-HSA-" in t else "")
fig, ax = plt.subplots(figsize=(13, 4.6), dpi=300)
y = np.arange(len(A)); ax.barh(y, -np.log10(A.q.values), color="#C0504D", height=0.6)
ax.axvline(-np.log10(0.25), ls="--", color="black", lw=0.8)
ax.text(-np.log10(0.25) + 0.03, len(A) - 0.45, "q = 0.25", fontsize=8)
ax.set_yticks(y); ax.set_yticklabels([nice(t) for t in A.index], fontsize=9)
ax.set_xlabel("-log$_{10}$ q, unadjusted analysis (scenario A)"); ax.set_xlim(0, 2.6)
ax.spines[["top", "right"]].set_visible(False)
xc = [2.75, 4.25, 5.45]
for x_, h in zip(xc, ["Contributing proteins\n(overlap/set size)", "Scenario C\n(panel excluded, adjusted)",
                      "Scenario D2\n(Hb chains: Hb-free index)"]):
    ax.text(x_, len(A) - 0.2, h, fontsize=8.5, fontweight="bold", va="bottom", clip_on=False)
for yi, (t, r) in zip(y, A.iterrows()):
    ax.text(xc[0], yi, f"{r['Contributing proteins'].replace(';', ', ')}  ({r.Overlap}/{r['Set size']})", fontsize=8.5, va="center", clip_on=False)
    ax.text(xc[1], yi, "no contributing protein", fontsize=8.5, va="center", color="#555", clip_on=False)
    d = D2.loc[t]
    txt, col = ((f"q = {d.q:.3f}  ({d['Contributing proteins'].replace(';', ', ')})", "#C0504D" if d.q < 0.25 else "#555")
                if d.Overlap >= 2 else ("HBA1 only; not tested", "#555"))
    ax.text(xc[2], yi, txt, fontsize=8.5, va="center", color=col, clip_on=False)
fig.subplots_adjust(left=0.30, right=0.62, top=0.86, bottom=0.13)
fig.savefig(c.RESULTS / "Figure3.png", dpi=300, facecolor="white", bbox_inches="tight")
print(pd.DataFrame(summary)[["Scenario", "List size", "Terms at q < 0.25"]].to_string(index=False))
