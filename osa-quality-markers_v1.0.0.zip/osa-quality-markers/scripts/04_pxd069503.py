"""PXD069503: Tables S15-S18 and Figure 7."""
import sys; from pathlib import Path; sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.ticker import FuncFormatter, LogLocator
from scipy import stats
from sklearn.metrics import roc_auc_score
from statsmodels.stats.multitest import multipletests
import common as c

X, grp = c.load_pxd069503()
P = c.geyer_panels()
mem = {k: c.quantified_members(v, X.columns) for k, v in P.items()}
idx = {k: X[m].sum(axis=1, skipna=True) / X.sum(axis=1, skipna=True) for k, m in mem.items()}
order = {"CON": 0, "M-OSA": 1, "S-OSA": 2}
rng = np.random.default_rng(c.SEED)
auc = lambda a, b: roc_auc_score(np.r_[np.ones(len(a)), np.zeros(len(b))], np.r_[a, b])

# ---- S15
rows = []
for p, v in idx.items():
    G = {k: v[grp == k].values for k in order}; osa = v[grp != "CON"].values
    r = {"Panel": p, "Members quantified": len(mem[p])}
    r.update({f"Index, {k}": G[k].mean() for k in order}); r["Index, all OSA"] = osa.mean()
    r["Kruskal-Wallis p"] = stats.kruskal(*G.values()).pvalue
    r["Spearman rho"], r["Spearman p"] = stats.spearmanr(grp.map(order), v)
    pairs = [("M-OSA", "CON"), ("S-OSA", "CON"), ("S-OSA", "M-OSA")]
    for a, b in pairs:
        e, lo, hi = c.gmr(G[a], G[b], rng); lab = f"{a}/{b}"
        r[f"GMR {lab}"], r[f"GMR {lab} 95% CI lower"], r[f"GMR {lab} 95% CI upper"] = e, lo, hi
        r[f"Welch p (log) {lab}"] = stats.ttest_ind(np.log(G[a]), np.log(G[b]), equal_var=False).pvalue
        r[f"Mann-Whitney p {lab}"] = stats.mannwhitneyu(G[a], G[b]).pvalue
        r[f"AUROC {lab}"] = auc(G[a], G[b])
    e, lo, hi = c.gmr(osa, G["CON"], rng)
    r["GMR all OSA/CON"], r["GMR all OSA/CON 95% CI lower"], r["GMR all OSA/CON 95% CI upper"] = e, lo, hi
    r["Fold of means all OSA/CON"] = osa.mean() / G["CON"].mean()
    r["Welch p (log) all OSA/CON"] = stats.ttest_ind(np.log(osa), np.log(G["CON"]), equal_var=False).pvalue
    r["Mann-Whitney p all OSA/CON"] = stats.mannwhitneyu(osa, G["CON"]).pvalue
    r["AUROC all OSA/CON"] = auc(osa, G["CON"]); r["Members"] = ";".join(mem[p])
    rows.append(r)
S15 = pd.DataFrame(rows); S15.to_csv(c.RESULTS / "S15_PXD069503_indices.csv", index=False)

# ---- S16
L = np.log2(X); keep = L.columns[(np.isfinite(L).sum() >= 0.7 * len(L)).values]
L = L.loc[:, ~L.columns.duplicated()] if L.columns.duplicated().any() else L
eri, pli = np.log2(idx["erythrocyte"].values), np.log2(idx["platelet"].values)
contrasts = {"all OSA vs CON": (grp != "CON", grp == "CON"), "S-OSA vs CON": (grp == "S-OSA", grp == "CON"),
             "M-OSA vs CON": (grp == "M-OSA", grp == "CON"), "S-OSA vs M-OSA": (grp == "S-OSA", grp == "M-OSA")}
out = pd.DataFrame({"Protein": list(keep)}); adj = {}
Lk = np.log2(X.loc[:, np.isfinite(np.log2(X)).sum().values >= 0.7 * len(X)])
for name, (a, b) in contrasts.items():
    s = (a | b).values; xx = a[s].astype(float).values
    d = c.differential(Lk.loc[s], xx, list(Lk.columns))
    d_adj = c.differential(Lk.loc[s], xx, [p for p in Lk.columns if p not in mem["erythrocyte"]], lambda p: eri[s])
    m = out.merge(d[["Protein", "beta", "SE", "p", "q"]].add_suffix(f" {name}").rename(columns={f"Protein {name}": "Protein"}), on="Protein", how="left")
    out = m; adj[name] = d_adj.set_index("Protein")
out.to_csv(c.RESULTS / "S16_PXD069503_differential.csv", index=False)
s = (grp != "CON").values | True
d_plt = c.differential(Lk, (grp != "CON").astype(float).values, [p for p in Lk.columns if p not in mem["platelet"]], lambda p: pli)

# ---- S17 concordance with PXD073409 adjustment-persistent proteins
s4 = pd.read_csv(c.RESULTS / "S4_DEP_comparison.csv"); s3 = pd.read_csv(c.RESULTS / "S3_DEP_adjusted.csv").set_index("Protein")
pers = s4[s4["Status (q < 0.25)"] == "persisted"].Protein
pers = [p for p in pers if p in set(out.Protein)]
o = out.set_index("Protein")
S17 = pd.DataFrame({"Protein": pers, "beta (PXD073409, adjusted)": s3.loc[pers, "beta"].values, "SE (PXD073409)": s3.loc[pers, "SE"].values})
for name in ["S-OSA vs CON", "all OSA vs CON"]:
    S17[f"beta (PXD069503, {name})"] = o.loc[pers, f"beta {name}"].values
    S17[f"SE (PXD069503, {name})"] = o.loc[pers, f"SE {name}"].values
    S17[f"q (PXD069503, {name})"] = o.loc[pers, f"q {name}"].values
    S17[f"beta (PXD069503, {name}, index-adjusted)"] = adj[name].reindex(pers).beta.values
    S17[f"q (PXD069503, {name}, index-adjusted)"] = adj[name].reindex(pers).q.values
    S17[f"Same direction ({name})"] = np.sign(S17["beta (PXD073409, adjusted)"]) == np.sign(S17[f"beta (PXD069503, {name})"])
    S17[f"Same direction ({name}, index-adjusted)"] = np.sign(S17["beta (PXD073409, adjusted)"]) == np.sign(S17[f"beta (PXD069503, {name}, index-adjusted)"])
conc = {}
for name in ["S-OSA vs CON", "all OSA vs CON"]:
    a_, b_ = S17["beta (PXD073409, adjusted)"].values, S17[f"beta (PXD069503, {name})"].values
    bs = [stats.spearmanr(a_[i], b_[i])[0] for i in (rng.integers(0, len(a_), len(a_)) for _ in range(c.N_BOOT))]
    conc[name] = (int(S17[f"Same direction ({name})"].sum()), len(S17), stats.spearmanr(a_, b_)[0], np.nanpercentile(bs, 2.5), np.nanpercentile(bs, 97.5))
S17.insert(3, "q (PXD073409, adjusted)", s3.loc[pers, "q"].values)
S17.to_csv(c.RESULTS / "S17_Concordance.csv", index=False)
pd.DataFrame([(k,) + v for k, v in conc.items()], columns=["Contrast", "Same direction", "n", "Spearman rho", "95% CI lower", "95% CI upper"]).to_csv(c.RESULTS / "S17_summary.csv", index=False)

# ---- S18 group assignment check against the source study (Zhao et al. 2026, Figure 2C-E)
def degs(a, b):
    up = dn = 0
    for p in range(X.shape[1]):
        u = np.log2(X.iloc[a.values, p]).dropna(); v = np.log2(X.iloc[b.values, p]).dropna()
        if len(u) < 2 or len(v) < 2: continue
        pv = stats.ttest_ind(u, v).pvalue; fc = 2 ** (u.mean() - v.mean())
        up += pv < 0.05 and fc >= 1.5; dn += pv < 0.05 and fc <= 0.67
    return up, dn
B1, B2, C = grp == "S-OSA", grp == "M-OSA", grp == "CON"
rep = {"S-OSA vs CON": (153, 137), "M-OSA vs CON": (155, 46), "S-OSA vs M-OSA": (22, 89)}
used = {"S-OSA vs CON": (B1, C), "M-OSA vs CON": (B2, C), "S-OSA vs M-OSA": (B1, B2)}
rev = {"S-OSA vs CON": (B2, C), "M-OSA vs CON": (B1, C), "S-OSA vs M-OSA": (B2, B1)}
S18 = pd.DataFrame([{"Contrast": k, "Reported increased": rep[k][0], "Reported decreased": rep[k][1],
                     "Increased, assignment used": degs(*used[k])[0], "Decreased, assignment used": degs(*used[k])[1],
                     "Increased, reversed assignment": degs(*rev[k])[0], "Decreased, reversed assignment": degs(*rev[k])[1]} for k in rep])
S18.to_csv(c.RESULTS / "S18_PXD069503_group_check.csv", index=False)

# ---- Figure 7
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
col = {"CON": "#4C78A8", "M-OSA": "#E3A23B", "S-OSA": "#C0504D"}
fig = plt.figure(figsize=(13.0, 8.0), dpi=300)
gs = GridSpec(2, 3, figure=fig, width_ratios=[1.25, 1, 1], wspace=0.42, hspace=0.45)
axA = fig.add_subplot(gs[:, 0]); D = S17.sort_values("beta (PXD073409, adjusted)", ascending=False).reset_index(drop=True)
y = np.arange(len(D))[::-1]
b1, s1, b2, s2 = D["beta (PXD073409, adjusted)"], D["SE (PXD073409)"], D["beta (PXD069503, S-OSA vs CON)"], D["SE (PXD069503, S-OSA vs CON)"]
axA.errorbar(b1, y + 0.17, xerr=1.96 * s1, fmt="o", color="black", ms=4, capsize=2, lw=1, label="PXD073409, severe vs non-OSA (index-adjusted)")
axA.errorbar(b2, y - 0.17, xerr=1.96 * s2, fmt="s", color="#3A6FB0", ms=4, capsize=2, lw=1, label="PXD069503, severe OSA vs control")
axA.axvline(0, color="grey", lw=0.8); axA.set_yticks(y); axA.set_yticklabels(D.Protein); axA.set_ylim(-1, len(D) + 1.6)
axA.set_xlabel("log$_2$ difference (95% CI)"); axA.legend(loc="upper center", fontsize=7.5, frameon=False, bbox_to_anchor=(0.5, 1.0))
axA.text(-0.12, 1.01, "A", transform=axA.transAxes, fontsize=14, fontweight="bold")
axB = fig.add_subplot(gs[0, 1:]); same = D["Same direction (S-OSA vs CON)"]
axB.scatter(b1[same], b2[same], c="#3A6FB0", s=28, label=f"Same direction ({same.sum()})")
axB.scatter(b1[~same], b2[~same], c="#C0504D", marker="^", s=34, label=f"Opposite ({(~same).sum()})")
for _, r in D.iterrows():
    if abs(r["beta (PXD069503, S-OSA vs CON)"]) >= 0.5 or not r["Same direction (S-OSA vs CON)"]:
        axB.annotate(r.Protein, (r["beta (PXD073409, adjusted)"], r["beta (PXD069503, S-OSA vs CON)"]), fontsize=6.5, xytext=(3, 2), textcoords="offset points", color="#444")
axB.axhline(0, color="grey", lw=0.8); axB.axvline(0, color="grey", lw=0.8)
n_, _, rho, lo, hi = conc["S-OSA vs CON"]
axB.text(0.98, 0.04, f"Spearman rho = +{rho:.2f} (95% CI {lo:.2f} to {hi:.2f})", transform=axB.transAxes, ha="right", fontsize=8)
axB.set_xlabel("log$_2$ difference, PXD073409 (severe vs non-OSA, index-adjusted)"); axB.set_ylabel("log$_2$ difference,\nPXD069503 (severe vs control)")
axB.legend(loc="upper right", fontsize=7.5, frameon=False); axB.text(-0.08, 1.03, "B", transform=axB.transAxes, fontsize=14, fontweight="bold")
sub = gs[1, 1:].subgridspec(1, 3, wspace=0.55); jit = np.random.default_rng(3)
for k, (p, lab) in enumerate({"erythrocyte": "Erythrocyte", "platelet": "Platelet", "coagulation": "Coagulation"}.items()):
    ax = fig.add_subplot(sub[0, k]); v = idx[p] * 100
    for j, g in enumerate(order):
        vv = v[grp == g].values; ax.scatter(j + jit.uniform(-0.18, 0.18, len(vv)), vv, s=12, color=col[g], zorder=2)
        ax.hlines(np.exp(np.log(vv).mean()), j - 0.28, j + 0.28, color="black", lw=1.6, zorder=3)
    ax.set_yscale("log"); ax.set_xticks([0, 1, 2]); ax.set_xticklabels(["Control", "Mild-\nmoderate", "Severe"], fontsize=7.5)
    r = S15.set_index("Panel").loc[p]; ptxt = "P < 0.001" if r["Spearman p"] < 0.001 else f"P = {r['Spearman p']:.3f}"
    ax.set_title(f"{lab}\nrho = {r['Spearman rho']:+.2f}, {ptxt}", fontsize=8)
    ax.yaxis.set_major_locator(LogLocator(subs=(1, 2, 5))); ax.yaxis.set_minor_locator(LogLocator(subs="auto"))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda t, _: f"{t:g}")); ax.yaxis.set_minor_formatter(plt.NullFormatter())
    if k == 0:
        ax.set_ylabel("Quality marker index (%)"); ax.text(-0.55, 1.12, "C", transform=ax.transAxes, fontsize=14, fontweight="bold")
fig.savefig(c.RESULTS / "Figure7.png", dpi=300, bbox_inches="tight", facecolor="white")
print(S18.to_string(index=False)); print(conc)
print("platelet-adjusted all-OSA vs CON, q < 0.05:", int((d_plt.q < 0.05).sum()))
