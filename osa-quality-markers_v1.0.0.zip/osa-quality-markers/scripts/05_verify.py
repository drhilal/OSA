"""Compare regenerated results with the published Supplementary Tables (reference/)."""
import sys; from pathlib import Path; sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import numpy as np, pandas as pd
import common as c

W = c.ROOT / "reference" / "Supplementary_Tables.xlsx"
checks = [  # (results file, sheet, key column, value columns as (results, sheet))
    ("S1_Quality_indices.csv", "S1_Quality_indices", "Panel", [("GMR severe/non-OSA", "GMR severe/non-OSA"), ("Kruskal-Wallis p", "Kruskal-Wallis p")]),
    ("S2_DEP_unadjusted.csv", "S2_DEP_unadjusted", "Protein", [("beta", "beta"), ("q", "q")]),
    ("S3_DEP_adjusted.csv", "S3_DEP_adjusted", "Protein", [("beta", "beta (adjusted log2 difference)"), ("q", "q")]),
    ("S11b_DEP_scenario_D_LOPO.csv", "S11b_DEP_scenario_D_LOPO", "Protein", [("q D1", "q D1"), ("q D2", "q D2")]),
    ("ORA_scenario_A.csv", "S6_ORA_unadjusted", "Term", [("p", "p"), ("q", "q")]),
    ("ORA_scenario_B.csv", "S9_ORA_scenario_ii", "Term", [("p", "p"), ("q", "q")]),
    ("ORA_scenario_C.csv", "S10_ORA_scenario_iii", "Term", [("p", "p"), ("q", "q")]),
    ("ORA_scenario_D2.csv", "S11c_ORA_scenario_D2", "Term", [("p", "p"), ("q", "q")]),
    ("S15_PXD069503_indices.csv", "S15_PXD069503_indices", "Panel", [("GMR S-OSA/CON", "GMR S-OSA/CON"), ("Spearman p", "Spearman p")]),
    ("S16_PXD069503_differential.csv", "S16_PXD069503_differential", "Protein", [("beta S-OSA vs CON", "beta S-OSA vs CON"), ("q all OSA vs CON", "q all OSA vs CON")]),
    ("S17_Concordance.csv", "S17_Concordance", "Protein", [("beta (PXD069503, S-OSA vs CON)", "beta (PXD069503, S-OSA vs CON)")]),
]
ok_all = True
for f, sheet, key, cols in checks:
    a = pd.read_csv(c.RESULTS / f).set_index(key)
    b = pd.read_excel(W, sheet_name=sheet)
    b = b[b[key].isin(a.index)].set_index(key)
    for ca, cb in cols:
        same = np.allclose(a.loc[b.index, ca].astype(float), b[cb].astype(float), rtol=1e-6, atol=1e-9, equal_nan=True)
        ok_all &= same
        print(f"{'OK  ' if same else 'DIFF'} {sheet:32s} {cb}")
print("All checks passed" if ok_all else "Some checks differ")
