# Erythrocyte-associated proteins and the reported oxidative-stress enrichment in OSA plasma proteomics

Code, input data and derived tables for the manuscript

> Yasar S, Yagin FH, Findik BN, Alzakari SA, Alkhalifa AK, Al-Hashem F, Tabnjh AK. *Erythrocyte-Associated Proteins Underlie the Reported Oxidative-Stress Enrichment in Plasma Proteomics of Obstructive Sleep Apnoea: A Secondary Quality Marker Analysis of Public Datasets.* Journal of Clinical Medicine (under review, manuscript jcm-4589897).

## Contents

```
data/Dataset.xlsx            input data (three sheets, see below)
data/ORA_terms_frozen.tsv    gene-set term sizes and contributing proteins used for enrichment
src/common.py                shared functions (panels, indices, differential abundance, enrichment)
scripts/01_quality_indices.py   Table S1, Figure 1
scripts/02_differential.py      Tables S2-S4, S11b, Table 2 (differential counts), Figure 5
scripts/03_enrichment.py        Tables S6, S9-S11, S11c, Table 2 (enrichment counts), Figure 3
scripts/04_pxd069503.py         Tables S15-S18, Figure 7
scripts/05_verify.py            compares regenerated results with reference/Supplementary_Tables.xlsx
original_pipeline/           scripts and input files of the original analysis (see its README)
reference/Supplementary_Tables.xlsx   Supplementary Tables as submitted
run_all.sh                   runs scripts 01-05; outputs are written to results/
```

Run with Python 3.11 or later and the packages in `requirements.txt`:

```
pip install -r requirements.txt
./run_all.sh
```

All random procedures use the seed 20261002 (4000 bootstrap resamples). The last script should report "All checks passed".

## Input data

`data/Dataset.xlsx` contains three third-party sources, redistributed for reproducibility; please cite the original publications when using them.

| Sheet | Source |
|---|---|
| `OSA_plasma_proteome` | PXD073409 (PRIDE); Müller et al., J Transl Med 2026;24:777. Protein-group intensities, 45 samples (15 non-OSA, 15 mild, 15 severe OSA), linear scale. |
| `OSA_plasma_proteome_2` | PXD069503 (iProX IPX0013741000); Zhao et al., J Proteome Res 2026;25:4419-4434. Proteome Discoverer protein table (normalised abundances). Columns F1-F15 are the severe OSA samples, F16-F30 the mild-to-moderate OSA samples and F31-F45 the controls; Table S18 shows that this assignment reproduces the differential results reported in the source study. |
| `Geyer_quality_panels` | Table EV2 of Geyer et al., EMBO Mol Med 2019;11:e10427 (CC BY 4.0). |

## Methods summary

- Quality marker indices: summed linear intensity of quantified panel members divided by total intensity. NIF3L1 and F13A1 are excluded from the erythrocyte and platelet panels; the coagulation index uses plasma-elevated members (positive plasma-serum difference).
- Differential abundance: ordinary least squares on log2 intensity, no imputation; proteins detected in at least 70% of samples and with at least 10 values in each compared group; Benjamini-Hochberg correction.
- Scenarios: A, all proteins unadjusted; B, erythrocyte panel members excluded; C, panel members excluded with the log2 erythrocyte index as covariate; D, all proteins with the index as covariate; D1, as D with a leave-one-protein-out index for each panel member; D2, as D1 with each haemoglobin chain adjusted for an index excluding all three haemoglobin chains.
- Enrichment: proteins with q < 0.25 and |log2 fold change| >= 0.5; one-sided hypergeometric test against the quantified background; terms with fewer than two contributing proteins assigned P = 1; Benjamini-Hochberg correction across all terms retained after the 5-500 set-size filter (906 for the 420-protein background, 855 for the 409-protein background).

## Gene-set libraries

The enrichment analysis used the Enrichr libraries GO_Biological_Process_2023, GO_Molecular_Function_2023, KEGG_2021_Human and Reactome_2022, retrieved through gseapy 1.3.1 on 28 August 2026 and again on 10 September 2026; both downloads gave identical set sizes and P values. Enrichr libraries change over time, so a fresh download can give different set sizes. `data/ORA_terms_frozen.tsv` lists all terms retained after the 5-500 set-size filter (906 in the 420-protein background, 855 in the 409-protein background) with their sizes in the analysed background, and the proteins that contributed in the reported lists for terms with at least two contributing proteins. This reproduces every reported P and q value without downloading the libraries; it is not a substitute for the full libraries.

## Licence

Code: MIT (see `LICENSE`). Derived tables and figures: CC BY 4.0. Third-party data in `data/Dataset.xlsx` remain under the terms of their original sources.
