"""Shared functions: data loading, quality marker panels, indices,
differential abundance and over-representation analysis."""
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import hypergeom
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "Dataset.xlsx"
FROZEN = ROOT / "data" / "ORA_terms_frozen.tsv"
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

SEED = 20261002
N_BOOT = 4000
HB = ["HBA1", "HBB", "HBD"]


# ------------------------------------------------------------------ panels
def geyer_panels():
    """Gene-symbol sets of the three panels (Table EV2 of Geyer et al., 2019).

    NIF3L1 (erythrocyte) and F13A1 (platelet) are excluded, as by the original
    authors. The coagulation index uses plasma-elevated members only, i.e. a
    positive plasma-serum t-test difference.
    """
    g = pd.read_excel(DATA, sheet_name="Geyer_quality_panels", header=None)
    col = g[1].astype(str)

    def block(title):
        start = col[col.str.contains(title, regex=False)].index[0]
        hdr = g.index[(g.index > start) & (col == "Protein names")][0]
        rows = []
        for i in range(hdr + 1, len(g)):
            if pd.isna(g.iloc[i, 2]):
                break
            rows.append(i)
        return hdr, rows

    _, ery = block("Quality marker panel for erythrocyte")
    _, plt_ = block("Quality marker panel for platelet")
    hdr, coa = block("Quality markers of the coagulation panel")
    diff_col = [j for j in g.columns if "Difference" in str(g.iloc[hdr, j])][0]
    entry = lambda i: set(str(g.iloc[i, 2]).split(";"))
    return {
        "erythrocyte": [entry(i) for i in ery if g.iloc[i, 2] != "NIF3L1"],
        "platelet": [entry(i) for i in plt_ if g.iloc[i, 2] != "F13A1"],
        "coagulation": [entry(i) for i in coa if float(g.iloc[i, diff_col]) > 0],
    }


def quantified_members(panel_entries, symbols):
    """Symbols present in the data that match any symbol of a panel entry."""
    s = set(symbols)
    return sorted({x for entry in panel_entries for x in entry if x in s})


def index(matrix, members, exclude=()):
    """Summed intensity of panel members divided by total intensity (linear scale).

    Proteins in `exclude` are removed from numerator and denominator."""
    mem = [m for m in members if m not in exclude]
    cols = [c for c in matrix.columns if c not in exclude]
    return matrix[mem].sum(axis=1, skipna=True) / matrix[cols].sum(axis=1, skipna=True)


# ------------------------------------------------------------------ data
def load_primary():
    """PXD073409: 45 samples x 492 protein groups, linear intensities."""
    d = pd.read_excel(DATA, sheet_name="OSA_plasma_proteome")
    return d.drop(columns=["Sample_ID", "Group"]).astype(float), d["Group"]


def load_pxd069503():
    """PXD069503 Proteome Discoverer table, transposed to samples x proteins.

    Deposited column order: F1-F15 severe OSA, F16-F30 mild-to-moderate OSA,
    F31-F45 controls. HBA2 is matched to HBA1."""
    d = pd.read_excel(DATA, sheet_name="OSA_plasma_proteome_2")
    sym = d["Gene names"].astype(str).str.split(";").str[0].replace({"HBA2": "HBA1"})
    m = d.drop(columns=["Description", "Gene names"]).astype(float).T
    m.columns = sym.values
    grp = pd.Series(["S-OSA"] * 15 + ["M-OSA"] * 15 + ["CON"] * 15, index=m.index)
    return m, grp


# ------------------------------------------------------------------ statistics
def ols(y, x, covars=()):
    ok = np.isfinite(y)
    X = sm.add_constant(np.column_stack([x[ok]] + [c[ok] for c in covars]))
    r = sm.OLS(y[ok], X).fit()
    lo, hi = r.conf_int()[1]
    return r.params[1], r.bse[1], lo, hi, r.pvalues[1]


def differential(log2, is_case, proteins, covar_fn=None, min_valid=10):
    """Difference in mean log2 abundance between groups by OLS, no imputation.

    A protein is tested when it has >= min_valid values in each group;
    covar_fn(protein) returns the covariate vector for that protein."""
    rows = []
    for p in proteins:
        y = log2[p].values
        if (np.isfinite(y[is_case == 1]).sum() < min_valid
                or np.isfinite(y[is_case == 0]).sum() < min_valid):
            continue
        cov = () if covar_fn is None else (covar_fn(p),)
        b, se, lo, hi, pv = ols(y, is_case, cov)
        fc = np.nanmean(y[is_case == 1]) - np.nanmean(y[is_case == 0])
        rows.append((p, fc, b, se, lo, hi, pv))
    df = pd.DataFrame(rows, columns=["Protein", "log2FC", "beta", "SE", "CI lower", "CI upper", "p"])
    df["q"] = multipletests(df.p, method="fdr_bh")[1]
    return df


def gmr(a, b, rng):
    """Ratio of geometric means with a percentile bootstrap 95% CI."""
    la, lb = np.log(a), np.log(b)
    est = np.exp(la.mean() - lb.mean())
    bs = np.exp([rng.choice(la, len(la)).mean() - rng.choice(lb, len(lb)).mean()
                 for _ in range(N_BOOT)])
    return est, np.percentile(bs, 2.5), np.percentile(bs, 97.5)


# ------------------------------------------------------------------ enrichment
def ora(gene_list, background_size):
    """One-sided hypergeometric test against the frozen term table.

    The table lists every term retained after the 5-500 set-size filter
    (906 for the 420-protein background, 855 for the 409-protein background).
    Terms with fewer than two contributing proteins are assigned P = 1;
    Benjamini-Hochberg over all retained terms."""
    t = pd.read_csv(FROZEN, sep="\t")
    kcol = f"Set size ({background_size}-protein background)"
    L = set(gene_list)
    out = []
    for _, r in t.iterrows():
        if pd.isna(r[kcol]):
            continue
        mem = set(str(r["Contributing proteins in reported lists (overlap >= 2)"]).split(";")) - {"nan"}
        hit = sorted(mem & L)
        k, K = len(hit), int(r[kcol])
        p = hypergeom.sf(k - 1, background_size, K, len(L)) if k >= 2 else 1.0
        out.append((r.Term, K, k, ";".join(hit), p))
    df = pd.DataFrame(out, columns=["Term", "Set size", "Overlap", "Contributing proteins", "p"])
    df["q"] = multipletests(df.p.values, method="fdr_bh")[1]
    return df.sort_values(["p", "Term"]).reset_index(drop=True)
